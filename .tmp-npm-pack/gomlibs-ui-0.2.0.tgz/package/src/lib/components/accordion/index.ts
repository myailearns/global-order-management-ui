export * from './gom-accordion.component';
