import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'gom-lib-accordion',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './gom-accordion.component.html',
  styleUrl: './gom-accordion.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GomAccordionComponent {
  @Input() title = '';
  @Input() subtitle = '';
  @Input() expanded = false;
  @Input() disabled = false;

  @Output() expandedChange = new EventEmitter<boolean>();
  @Output() toggleState = new EventEmitter<boolean>();

  onTriggerClick(): void {
    if (this.disabled) {
      return;
    }

    const next = !this.expanded;
    this.expanded = next;
    this.expandedChange.emit(next);
    this.toggleState.emit(next);
  }
}
