export interface MenuList {
  mainMenu: MainMenuList[];
  portalMenu: PrimaryMenuList[];
}

export interface PrimaryMenuList {
  id?: string;
  title: string;
  icon: string;
  clickEvent?: (event: Event) => void;
}

export interface MainMenuList extends PrimaryMenuList {
  submenu?: SubMenuList[];
  subMenuOpen?: boolean;
  subMenuWidth?: number;
  level?: number;
}

export interface SubMenuList extends MainMenuList {
  title: string;
  route?: string;
}
