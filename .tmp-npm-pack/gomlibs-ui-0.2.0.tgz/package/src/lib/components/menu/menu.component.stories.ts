import { Component, input } from '@angular/core';
import { ButtonModule } from '../buttons';
import { Meta, moduleMetadata, StoryObj } from '@storybook/angular';
import { MenuList } from './menu.model';
import { TranslateModule } from '@ngx-translate/core';
import { LinkModule } from '../link/link.module';
import { MenuModule } from './menu.module';

@Component({
    selector: 'core-lib-menu-story',
    template: `
    <core-lib-menu
      #sideNav
      [menuList]="menuList()"
      [showMenuListArrow]="showMenuListArrow()"
      [showMobileBackArrow]="showMobileBackArrow()"
      [mobileBackArrowIcon]="mobileBackArrowIcon()"
      [backButtonText]="backButtonText()"
    ></core-lib-menu>
    <button
      coreLibButton
      [size]="'large'"
      [variant]="'primary'"
      (click)="sideNav.toggle()"
    >
      Click to toggle
    </button>

    <br />
    <br />
  `,
    imports: [ButtonModule, LinkModule, TranslateModule, MenuModule]
})
export class MenuStoryComponent {
  menuList = input<MenuList>();
  showMenuListArrow = input<boolean>(true);
  showMobileBackArrow = input<boolean>(true);
  mobileBackArrowIcon = input<string>('ri-arrow-left-s-line');
  backButtonText = input<string>('Back');
}

const menuListObj: MenuList = {
  mainMenu: [
    {
      title: 'About',
      icon: 'ri-database-line',
      clickEvent: () => {
        return;
      },
    },
    {
      title: 'Home',
      icon: 'ri-home-line',
      submenu: [
        {
          title: 'Dashboard',
          icon: 'ri-dashboard-line',
          submenu: [
            {
              title: 'Settings',
              icon: 'ri-tools-line',
              clickEvent: () => {
                return;
              },
            },
          ],
        },
        {
          title: 'Dashboard2',
          icon: 'ri-dashboard-line',
          clickEvent: () => {
            return;
          },
        },
      ],
    },
    {
      title: 'Vehicle Information',
      icon: 'ri-car-line',
      clickEvent: () => {
        return;
      },
    },
    {
      title: 'Library',
      icon: 'ri-book-2-line',
      clickEvent: () => {
        return;
      },
    },
    {
      title: 'Flat Rate Manual',
      icon: 'ri-hourglass-line',
      clickEvent: () => {
        return;
      },
    },
    {
      title: 'Case Management Center',
      icon: 'ri-archive-2-line',
      clickEvent: () => {
        return;
      },
    },
  ],
  portalMenu: [
    {
      title: 'Delar',
      icon: './static/Icon.svg',
      clickEvent: () => {
        return;
      },
    },
    {
      title: 'Telematics Portal',
      icon: './static/Icon.svg',
      clickEvent: () => {
        return;
      },
    },
    {
      title: 'ADAS',
      icon: './static/Icon.svg',
      clickEvent: () => {
        return;
      },
    },
    {
      title: 'Toyota Engage',
      icon: './static/Icon.svg',
      clickEvent: () => {
        return;
      },
    },
    {
      title: 'T-Ten',
      icon: './static/Icon.svg',
      clickEvent: () => {
        return;
      },
    },
  ],
};

const meta: Meta<MenuStoryComponent> = {
  title: 'CoreLib/Menu',
  component: MenuStoryComponent,
  parameters: {
    docs: {
      description: {
        component: `Import\n\n\`\`\`ts\nimport { MenuModule } from '@toyota/naqp-dev-web-core-components-library/components';\n\`\`\`\n\nAdd the module(s) to your Angular feature module imports.`,
      },
    },
  },
  decorators: [
    moduleMetadata({
      imports: [MenuStoryComponent, MenuModule],
    }),
  ],
  argTypes: {
    menuList: {
      description: 'Menu List Object',
      control: {
        type: 'text',
        disable: true,
      },
      table: {
        type: {
          summary: 'MenuList',
        },
        defaultValue: {
          summary: '{}',
        },
      },
      type: 'string',
    },
  },
};

export default meta;

export const Menu: StoryObj<MenuStoryComponent> = {
  parameters: {
    docs: {
      source: {
        code: `
// Below code is used to implement menu component
 <core-lib-menu
      #sideNav
      [menuList]='${JSON.stringify(menuListObj)}'
      [showMenuListArrow]="true"
      [showMobileBackArrow]="true"
      [mobileBackArrowIcon]="'ri-arrow-left-s-line'"
      [backButtonText]="'Back' | translate"
    ></core-lib-menu>

// menuList should be of type MenuList from core components library
// Use below code on any event to toggle menu component
<button coreLibButton(click)="sideNav.toggle()"></button>
        `,
        language: 'js',
        type: 'auto',
      },
    },
  },
  args: {
    menuList: menuListObj,
    showMenuListArrow: true,
    showMobileBackArrow: true,
    mobileBackArrowIcon: 'ri-arrow-left-s-line',
  },
};
