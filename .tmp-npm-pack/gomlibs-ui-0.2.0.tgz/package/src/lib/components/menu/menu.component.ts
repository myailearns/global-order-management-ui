import { CommonModule } from '@angular/common';
import { Component, ElementRef, computed, HostListener, inject, input, model } from '@angular/core';
import {
  MainMenuList,
  MenuList,
  PrimaryMenuList,
  SubMenuList,
} from './menu.model';

@Component({
    selector: 'core-lib-menu',
    standalone: true,
    templateUrl: './menu.component.html',
    styleUrl: './menu.component.scss',
    host: {
      '[class.submenu-host]': 'menuType() === "submenu"',
    },
  imports: [CommonModule]
})
export class MenuComponent {
  menuList = input.required<MenuList>();
  menuType = input<'sidebar' | 'submenu'>('sidebar');
  outsideClickBoundary = input<HTMLElement | null>(null);
  showMenuListArrow = input<boolean>(true);
  showMobileBackArrow = input<boolean>(true);
  mobileBackArrowIcon = input<string>('ri-arrow-left-s-line');
  backButtonText = input<string>('');
  protected showSideNavOpen = model<boolean>(false);
  private readonly elementRef = inject(ElementRef<HTMLElement>);
  private lastOpenedAt = 0;
  protected updatedMenuList = computed<MenuList>(
    (): MenuList =>
      this.showSideNavOpen()
        ? {
            mainMenu: this.addSubMenuOpen(this.menuList().mainMenu),
            portalMenu: this.addSubMenuOpen(this.menuList().portalMenu),
          }
        : this.menuList(),
  );

  @HostListener('document:keydown.escape', ['$event'])
  onKeydownHandler(_event: KeyboardEvent): void {
    if (this.showSideNavOpen()) {
      this.close();
    }
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (!this.showSideNavOpen() || this.menuType() !== 'submenu') {
      return;
    }

    if (Date.now() - this.lastOpenedAt < 50) {
      return;
    }

    const target = event.target;
    if (!(target instanceof Node)) {
      return;
    }

    const hostElement = this.elementRef.nativeElement;
    const boundaryElement = this.outsideClickBoundary() ?? hostElement;

    if (!hostElement.contains(target) && !boundaryElement.contains(target)) {
      this.close();
    }
  }

  toggle(): void {
    if (this.showSideNavOpen()) {
      this.close();
      return;
    }

    this.lastOpenedAt = Date.now();
    this.showSideNavOpen.set(true);
  }

  close(): void {
    this.showSideNavOpen.set(false);
  }

  protected updateItem(
    menuArr: MainMenuList[] | SubMenuList[],
    index: number,
  ): MainMenuList[] | SubMenuList[] {
    return menuArr.map((item, i) => {
      if (index !== null) {
        if (i !== index) {
          item.subMenuOpen = false;
        } else {
          item.subMenuOpen = true;
        }
      } else {
        item.subMenuOpen = false;
      }
      return item;
    });
  }

  addSubMenuOpen(
    menu: MainMenuList[] | PrimaryMenuList[],
  ): MainMenuList[] | PrimaryMenuList[] {
    return menu.map((item) => {
      if (this.hasNestedMenu(item)) {
        item.subMenuOpen = false;
      }

      if ('submenu' in item && Array.isArray(item.submenu)) {
        this.addSubMenuOpen(item.submenu);
      }

      return item;
    });
  }

  private hasNestedMenu(item: MainMenuList | PrimaryMenuList): item is MainMenuList {
    return 'subMenuOpen' in item || 'submenu' in item;
  }
}
