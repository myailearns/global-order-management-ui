import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MenuComponent } from './menu.component';
import { TranslateModule } from '@ngx-translate/core';
import { MainMenuList } from './menu.model';

describe('MenuComponent', () => {
  let component: MenuComponent;
  let fixture: ComponentFixture<MenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MenuComponent, TranslateModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should correctly update subMenuOpen status for menu items', () => {
    const menuArr = [
      { name: 'Item 1', subMenuOpen: false },
      { name: 'Item 2', subMenuOpen: false },
    ];

    const updatedMenuArr = (component as any).updateItem(menuArr, 0);

    expect(updatedMenuArr[0].subMenuOpen).toBe(true);
    expect(updatedMenuArr[1].subMenuOpen).toBe(false);

    const updatedMenuArr2 = (component as any).updateItem(menuArr, null);

    expect(updatedMenuArr2[0].subMenuOpen).toBe(false);
    expect(updatedMenuArr2[1].subMenuOpen).toBe(false);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should set subMenuOpen to false for all menu items including nested submenus', () => {
    const menu: MainMenuList[] = [
      {
        title: 'Main Item 1',
        icon: 'icon1',
        submenu: [
          {
            title: 'Sub Item 1',
            icon: 'icon2',
          },
          {
            title: 'Sub Item 2',
            icon: 'icon3',
            submenu: [
              {
                title: 'Sub Sub Item 1',
                icon: 'icon4',
              },
            ],
          },
        ],
      },
      {
        title: 'Main Item 2',
        icon: 'icon5',
      },
    ];

    const updatedMenu = component.addSubMenuOpen(menu);

    // Check that all items have subMenuOpen set to false
    updatedMenu.forEach((item) => {
      expect(item.subMenuOpen).toBe(false);
      if (item.submenu && item.submenu.length > 0) {
        item.submenu.forEach((subItem) => {
          expect(subItem.subMenuOpen).toBe(false);
        });
      }
    });
  });
});
