import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'gom-lib-button',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './gom-button.component.html',
  styleUrl: './gom-button.component.scss',
})
export class GomButtonComponent {
  @Input() type: 'button' | 'submit' | 'reset' = 'button';
  @Input() variant: 'primary' | 'secondary' | 'danger' | 'ghost' = 'primary';
  @Input() size: 'default' | 'icon' | 'compact-icon' = 'default';
  @Input() disabled = false;
  @Input() ariaLabel = '';
  @Input() ariaExpanded: boolean | null = null;
  @Input() ariaHaspopup: 'menu' | 'dialog' | null = null;
  @Input() ariaCurrent: 'page' | null = null;
  @Input() buttonTitle = '';
  @Input() ariaRole = '';

  @Output() buttonClick = new EventEmitter<MouseEvent>();

  handleClick(event: MouseEvent): void {
    if (this.disabled) {
      event.preventDefault();
      return;
    }
    this.buttonClick.emit(event);
  }
}
