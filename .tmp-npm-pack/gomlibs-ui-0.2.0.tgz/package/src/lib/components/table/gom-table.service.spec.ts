import { GomTableService } from './gom-table.service';
import { GomTableColumn, GomTableFilterDefinition, GomTableQuery, GomTableRow } from './gom-table.models';

interface TestRow extends GomTableRow {
  id: number;
  name: string;
  hiddenCode: string;
  status: string;
  createdAt: string;
  amount?: string;
  rawAmount?: number;
}

describe('GomTableService', () => {
  const service = new GomTableService();
  const rows: TestRow[] = [
    { id: 1, name: 'Alpha', hiddenCode: 'SECRET-1', status: 'ACTIVE', createdAt: '2026-08-01' },
    { id: 2, name: 'Beta', hiddenCode: 'SECRET-2', status: 'INACTIVE', createdAt: '2026-08-20' },
  ];
  const columns: GomTableColumn<TestRow>[] = [
    { key: 'name', header: 'Name' },
    { key: 'hiddenCode', header: 'Hidden code', hiddenByDefault: true },
    { key: 'status', header: 'Status' },
  ];
  const baseQuery: GomTableQuery = {
    searchTerm: '',
    sort: { key: '', direction: '' },
    pageIndex: 0,
    pageSize: 10,
    filters: {},
    visibleColumnKeys: ['name', 'status'],
  };

  it('searches visible columns by default', () => {
    const result = service.runClientPipeline(rows, columns, { ...baseQuery, searchTerm: 'SECRET-1' });
    expect(result.filteredTotal).toBe(0);
  });

  it('can search hidden columns when configured', () => {
    const result = service.runClientPipeline(rows, columns, {
      ...baseQuery,
      searchTerm: 'SECRET-1',
      globalSearchScope: 'all',
    });
    expect(result.rows.map((row) => row.id)).toEqual([1]);
  });

  it('applies select and date-range advanced filters', () => {
    const definitions: GomTableFilterDefinition<TestRow>[] = [
      { key: 'status', label: 'Status', type: 'select' },
      { key: 'createdAt', label: 'Created', type: 'date-range' },
    ];
    const result = service.runClientPipeline(rows, columns, {
      ...baseQuery,
      advancedFilters: {
        status: 'INACTIVE',
        createdAt: { from: '2026-08-10', to: '2026-08-31' },
      },
    }, definitions);
    expect(result.rows.map((row) => row.id)).toEqual([2]);
  });

  it('sorts by a column raw-value accessor instead of its formatted display value', () => {
    const amountRows: TestRow[] = [
      { ...rows[0], amount: 'Rs 1,250', rawAmount: 1250 },
      { ...rows[1], amount: 'Rs 950', rawAmount: 950 },
    ];
    const amountColumns: GomTableColumn<TestRow>[] = [
      ...columns,
      { key: 'amount', header: 'Amount', sortable: true, sortValue: (row) => row.rawAmount },
    ];

    const result = service.runClientPipeline(amountRows, amountColumns, {
      ...baseQuery,
      sort: { key: 'amount', direction: 'asc' },
    });

    expect(result.rows.map((row) => row.id)).toEqual([2, 1]);
  });
});