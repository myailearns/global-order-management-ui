import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { GomTableComponent } from './gom-table.component';
import {
  GomTableBulkAction,
  GomTableColumn,
  GomTableFilterDefinition,
  GomTableFilterNavigationRow,
  GomTableRow,
} from './gom-table.models';

interface TestRow extends GomTableRow {
  id: number;
  status: string;
  source?: string;
  price?: number;
}

describe('GomTableComponent filter navigation', () => {
  let fixture: ComponentFixture<GomTableComponent<TestRow>>;
  let component: GomTableComponent<TestRow>;

  const columns: GomTableColumn<TestRow>[] = [
    { key: 'id', header: 'ID' },
    { key: 'status', header: 'Status' },
  ];
  const rows: TestRow[] = [
    { id: 1, status: 'ACTIVE', source: 'WEB' },
    { id: 2, status: 'INACTIVE', source: 'STORE' },
  ];
  const filterDefinitions: GomTableFilterDefinition<TestRow>[] = [
    {
      key: 'status',
      label: 'Status',
      type: 'select',
      options: [
        { label: 'Active', value: 'ACTIVE' },
        { label: 'Inactive', value: 'INACTIVE' },
      ],
    },
  ];
  const navigationRows: GomTableFilterNavigationRow<TestRow>[] = [
    {
      key: 'status',
      label: 'Status',
      options: [
        { label: 'Active', value: 'ACTIVE' },
        { label: 'Inactive', value: 'INACTIVE' },
      ],
    },
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GomTableComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(GomTableComponent<TestRow>);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('columns', columns);
    fixture.componentRef.setInput('rows', rows);
    fixture.componentRef.setInput('advancedFilterDefinitions', filterDefinitions);
    fixture.componentRef.setInput('filterNavigationRows', navigationRows);
    fixture.componentRef.setInput('showClearFilterButton', true);
  });

  it('filters through a navigation option and synchronizes advanced filters', fakeAsync(() => {
    fixture.detectChanges();
    tick();

    component.selectFilterNavigationOption(navigationRows[0], navigationRows[0].options![0]);
    fixture.detectChanges();

    expect(component.advancedFilters['status']).toBe('ACTIVE');
    expect(component.displayedRows).toEqual([rows[0]]);
    expect(component.activeFilterCount).toBe(1);
    const activeChip = fixture.nativeElement.querySelector(
      '.gom-table-filter-navigation__option .gom-chip--selected'
    ) as HTMLButtonElement | null;
    expect(activeChip?.textContent?.trim()).toBe('Active');
  }));

  it('updates the selected navigation chip when a modal filter is applied', fakeAsync(() => {
    fixture.detectChanges();
    tick();

    component.draftAdvancedFilters = { status: 'INACTIVE' };
    component.applyAdvancedFilters();
    fixture.detectChanges();

    const activeChip = fixture.nativeElement.querySelector(
      '.gom-table-filter-navigation__option .gom-chip--selected'
    ) as HTMLButtonElement | null;
    expect(activeChip?.textContent?.trim()).toBe('Inactive');
    expect(component.advancedFilters['status']).toBe('INACTIVE');
  }));

  it('shows the configured clear button only while a filter is active', fakeAsync(() => {
    fixture.detectChanges();
    tick();
    expect(fixture.nativeElement.querySelector('.gom-table-clear-filters')).toBeNull();

    component.selectFilterNavigationOption(navigationRows[0], navigationRows[0].options![0]);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.gom-table-clear-filters')).not.toBeNull();

    component.clearAllFilters();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.gom-table-clear-filters')).toBeNull();
  }));

  it('moves options beyond the visible count into the overflow collection', () => {
    component.navigationVisibleOptionCounts = { status: 2 };

    expect(component.getVisibleFilterNavigationOptions(navigationRows[0]).length).toBe(2);
    expect(component.getOverflowFilterNavigationOptions(navigationRows[0]).length).toBe(1);
  });

  it('derives unique navigation options and counts from table rows', fakeAsync(() => {
    const dynamicNavigationRow: GomTableFilterNavigationRow<TestRow> = {
      key: 'source',
      label: 'Source',
      optionSource: 'rows',
      showCounts: true,
    };
    fixture.componentRef.setInput('rows', [
      ...rows,
      { id: 3, status: 'ACTIVE', source: 'WEB' },
      { id: 4, status: 'ACTIVE', source: '  ' },
    ]);
    fixture.componentRef.setInput('filterNavigationRows', [dynamicNavigationRow]);
    fixture.detectChanges();
    tick();

    expect(component.getFilterNavigationOptions(dynamicNavigationRow)).toEqual([
      { label: 'All', value: '', count: 4 },
      { label: 'WEB', value: 'WEB', count: 2 },
      { label: 'STORE', value: 'STORE', count: 1 },
    ]);
  }));

  it('shows configured bulk actions and emits selected rows to the consumer', fakeAsync(() => {
    const actions: GomTableBulkAction<TestRow>[] = [
      { actionKey: 'change-status', label: 'Change status', icon: 'ri-exchange-line' },
    ];
    const emittedEvents: unknown[] = [];
    fixture.componentRef.setInput('enableRowSelection', true);
    fixture.componentRef.setInput('bulkActions', actions);
    component.bulkAction.subscribe((event) => emittedEvents.push(event));
    fixture.detectChanges();
    tick();

    component.toggleRowSelection(rows[0], 0, true);
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.gom-table-bulk-actions')).not.toBeNull();
    expect(component.selectionSummary).toBe('1 row selected');

    component.triggerBulkAction(actions[0]);
    expect(emittedEvents).toEqual([{
      actionKey: 'change-status',
      selectedRows: [rows[0]],
      selectedRowKeys: ['0:0'],
    }]);
  }));

  it('does not emit disabled bulk actions and supports clearing selection', fakeAsync(() => {
    const action: GomTableBulkAction<TestRow> = {
      actionKey: 'restricted',
      label: 'Restricted',
      disabled: () => true,
    };
    let emissionCount = 0;
    fixture.componentRef.setInput('enableRowSelection', true);
    fixture.componentRef.setInput('bulkActions', [action]);
    component.bulkAction.subscribe(() => emissionCount += 1);
    fixture.detectChanges();
    tick();

    component.toggleRowSelection(rows[0], 0, true);
    component.triggerBulkAction(action);
    expect(emissionCount).toBe(0);

    component.clearSelectedRows();
    fixture.detectChanges();
    expect(component.selectedRowCount).toBe(0);
    expect(fixture.nativeElement.querySelector('.gom-table-bulk-actions')).toBeNull();
  }));

  it('calculates the displayed pagination range for client and empty datasets', fakeAsync(() => {
    fixture.componentRef.setInput('rows', Array.from({ length: 23 }, (_, index) => ({
      id: index + 1,
      status: 'ACTIVE',
    })));
    fixture.componentRef.setInput('pageSize', 10);
    fixture.componentRef.setInput('pageIndex', 1);
    fixture.detectChanges();
    tick();

    expect(component.paginationTotal).toBe(23);
    expect(component.paginationRangeStart).toBe(11);
    expect(component.paginationRangeEnd).toBe(20);

    fixture.componentRef.setInput('rows', []);
    fixture.componentRef.setInput('pageIndex', 0);
    fixture.detectChanges();
    tick();

    expect(component.paginationRangeStart).toBe(0);
    expect(component.paginationRangeEnd).toBe(0);
    expect(component.totalPages).toBe(1);
  }));

  it('creates compact page windows with ellipses', () => {
    component.dataMode = 'server';
    component.totalItems = 1250;
    component.pageSize = 10;

    component.pageIndex = 0;
    expect(component.paginationItems).toEqual([1, 2, 3, 'ellipsis-end', 125]);

    component.pageIndex = 61;
    expect(component.paginationItems).toEqual([
      1,
      'ellipsis-start',
      61,
      62,
      63,
      'ellipsis-end',
      125,
    ]);

    component.pageIndex = 123;
    expect(component.paginationItems).toEqual([1, 'ellipsis-start', 123, 124, 125]);
  });

  it('navigates directly to a page and emits the existing paging contracts', () => {
    const pageEvents: unknown[] = [];
    const queryEvents: unknown[] = [];
    component.dataMode = 'server';
    component.totalItems = 100;
    component.pageSize = 10;
    component.pageIndex = 0;
    component.pageChange.subscribe((event) => pageEvents.push(event));
    component.queryChange.subscribe((event) => queryEvents.push(event));

    component.goToPage(5);

    expect(component.pageIndex).toBe(4);
    expect(pageEvents).toEqual([{ pageIndex: 4, pageSize: 10 }]);
    expect(queryEvents.length).toBe(1);
    expect((queryEvents[0] as { pageIndex: number }).pageIndex).toBe(4);
  });

  it('renders the active page and accessible pagination controls', fakeAsync(() => {
    fixture.componentRef.setInput('dataMode', 'server');
    fixture.componentRef.setInput('totalItems', 100);
    fixture.componentRef.setInput('pageSize', 10);
    fixture.componentRef.setInput('pageIndex', 1);
    fixture.detectChanges();
    tick();

    const currentPage = fixture.nativeElement.querySelector(
      '.gom-table-page-button button[aria-current="page"]'
    ) as HTMLButtonElement | null;
    const pageSize = fixture.nativeElement.querySelector(
      '.gom-table-page-size-select button[aria-label="Rows per page"]'
    ) as HTMLButtonElement | null;

    expect(currentPage?.textContent?.trim()).toBe('2');
    expect(pageSize?.textContent?.trim()).toContain('Show 10');
  }));

  it('builds and removes mobile applied-filter chips', fakeAsync(() => {
    fixture.detectChanges();
    tick();
    component.advancedFilters = { status: 'ACTIVE' };

    expect(component.appliedFilterChips).toEqual([{
      key: 'advanced:status',
      label: 'Status',
      displayValue: 'Active',
    }]);

    component.removeAppliedFilter('advanced:status');
    expect(component.appliedFilterChips).toEqual([]);
  }));

  it('supports checkbox-style draft filter selections', () => {
    const filter: GomTableFilterDefinition<TestRow> = {
      ...filterDefinitions[0],
      type: 'multi-select',
      mobileControl: 'checkboxes',
    };

    component.toggleDraftFilterOption(filter, 'ACTIVE');
    component.toggleDraftFilterOption(filter, 'INACTIVE');
    expect(component.getFilterArray(component.draftAdvancedFilters, 'status')).toEqual(['ACTIVE', 'INACTIVE']);
    expect(component.draftAdvancedFilterCount).toBe(1);

    component.toggleDraftFilterOption(filter, 'ACTIVE');
    expect(component.getFilterArray(component.draftAdvancedFilters, 'status')).toEqual(['INACTIVE']);
  });

  it('reads configured mobile card values and initials', () => {
    component.mobileCardConfig = {
      primaryKey: 'id',
      titleKey: 'status',
      avatarKey: 'status',
    };

    expect(component.getMobileCardValue(rows[0], 'id')).toBe('1');
    expect(component.getMobileCardInitials(rows[0])).toBe('A');
  });

  it('limits mobile sort options to configured sortable columns in configured order', () => {
    component.columns = [
      { key: 'id', header: 'ID', sortable: true },
      { key: 'status', header: 'Status', sortable: true },
      { key: 'source', header: 'Source' },
    ];
    component.mobileSortKeys = ['status', 'source', 'id'];

    expect(component.mobileSortColumns.map((column) => column.key)).toEqual(['status', 'id']);
  });

  it('defaults mobile results to list cards and allows switching to table view', () => {
    component.mobileCardView = true;
    component.isMobileViewport = true;

    expect(component.mobileViewMode).toBe('cards');
    expect(component.isMobileCardsActive).toBeTrue();

    component.setMobileViewMode('table');

    expect(component.isMobileTableActive).toBeTrue();
    expect(component.isMobileCardsActive).toBeFalse();
  });

  it('opens table column controls from mobile table options', () => {
    component.enableColumnSearch = true;
    component.mobileTableOptionsOpen = true;

    component.toggleMobileColumnSearch();

    expect(component.filtersVisible).toBeTrue();
    expect(component.mobileTableOptionsOpen).toBeFalse();

    component.mobileTableOptionsOpen = true;
    component.openMobileColumnPanel();

    expect(component.columnPanelOpen).toBeTrue();
    expect(component.mobileTableOptionsOpen).toBeFalse();
  });

  it('emits the next page without mutating paging state in mobile load-more mode', () => {
    const events: unknown[] = [];
    component.dataMode = 'server';
    component.totalItems = 30;
    component.pageSize = 10;
    component.pageIndex = 0;
    component.loadMore.subscribe((event) => events.push(event));

    component.requestLoadMore();

    expect(events).toEqual([{ pageIndex: 1, pageSize: 10 }]);
    expect(component.pageIndex).toBe(0);
  });

  it('keeps columns read-only unless editable is configured', fakeAsync(() => {
    fixture.detectChanges();
    tick();

    expect(fixture.nativeElement.querySelector('.gom-table-cell-editor')).toBeNull();
    expect(fixture.nativeElement.querySelector('.gom-table-cell-edit-trigger')).toBeNull();
  }));

  it('uses click-to-edit by default and emits a controlled numeric edit without mutating the row', fakeAsync(() => {
    const editableRows: TestRow[] = [{ id: 1, status: 'ACTIVE', price: 100 }];
    const editableColumns: GomTableColumn<TestRow>[] = [
      { key: 'status', header: 'Item' },
      {
        key: 'price',
        header: 'Price',
        format: (value) => `$${Number(value).toFixed(2)}`,
        editable: { type: 'number', min: 0, step: 0.01 },
      },
    ];
    const events: unknown[] = [];
    fixture.componentRef.setInput('columns', editableColumns);
    fixture.componentRef.setInput('rows', editableRows);
    component.cellEdit.subscribe((event) => {
      events.push(event);
      fixture.componentRef.setInput('rows', editableRows.map((item) => (
        item.id === event.row.id ? { ...item, price: event.value } : { ...item }
      )));
    });
    fixture.detectChanges();
    tick();

    const trigger = fixture.nativeElement.querySelector('.gom-table-cell-edit-trigger') as HTMLButtonElement;
    expect(trigger.textContent?.trim()).toBe('$100.00');
    trigger.click();
    fixture.detectChanges();
    tick();

    const input = fixture.nativeElement.querySelector('.gom-table-cell-editor input') as HTMLInputElement;
    input.value = '120.25';
    input.dispatchEvent(new Event('input'));
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    fixture.detectChanges();

    expect(events).toEqual([{
      row: editableRows[0],
      columnKey: 'price',
      previousValue: 100,
      value: 120.25,
    }]);
    expect(editableRows[0].price).toBe(100);
    expect(fixture.nativeElement.querySelector('.gom-table-cell-editor')).toBeNull();
  }));

  it('preserves an intermediate decimal draft and commits the decimal value', fakeAsync(() => {
    const editableRows: TestRow[] = [{ id: 1, status: 'ACTIVE', price: 151 }];
    const editableColumn: GomTableColumn<TestRow> = {
      key: 'price',
      header: 'Price',
      editable: { type: 'number', min: 0.01, step: 0.01 },
    };
    const events: unknown[] = [];
    fixture.componentRef.setInput('columns', [editableColumn]);
    fixture.componentRef.setInput('rows', editableRows);
    component.cellEdit.subscribe((event) => events.push(event));
    fixture.detectChanges();
    tick();

    const trigger = fixture.nativeElement.querySelector('.gom-table-cell-edit-trigger') as HTMLButtonElement;
    trigger.click();
    fixture.detectChanges();
    tick();

    const input = fixture.nativeElement.querySelector('.gom-table-cell-editor input') as HTMLInputElement;
    expect(input.type).toBe('text');
    expect(input.inputMode).toBe('decimal');

    input.value = '151.';
    input.dispatchEvent(new Event('input', { bubbles: true }));
    fixture.detectChanges();
    expect(component.getCellDraft(editableRows[0], editableColumn)).toBe('151.');
    expect(input.value).toBe('151.');

    input.value = '151.25';
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    fixture.detectChanges();

    expect(events).toEqual([{
      row: editableRows[0],
      columnKey: 'price',
      previousValue: 151,
      value: 151.25,
    }]);
  }));

  it('accepts comma-decimal input and commits as a numeric decimal value', fakeAsync(() => {
    const editableRows: TestRow[] = [{ id: 1, status: 'ACTIVE', price: 80 }];
    const editableColumn: GomTableColumn<TestRow> = {
      key: 'price',
      header: 'Price',
      editable: { type: 'number', min: 0.01, step: 0.01 },
    };
    const events: unknown[] = [];
    fixture.componentRef.setInput('columns', [editableColumn]);
    fixture.componentRef.setInput('rows', editableRows);
    component.cellEdit.subscribe((event) => events.push(event));
    fixture.detectChanges();
    tick();

    component.startCellEdit(new Event('click'), editableRows[0], editableColumn);
    fixture.detectChanges();
    tick();

    const input = fixture.nativeElement.querySelector('.gom-table-cell-editor input') as HTMLInputElement;
    input.value = '80,75';
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    fixture.detectChanges();

    expect(events).toEqual([{
      row: editableRows[0],
      columnKey: 'price',
      previousValue: 80,
      value: 80.75,
    }]);
  }));

  it('renders always-edit inputs and enforces numeric constraints before emitting', fakeAsync(() => {
    const editableRows: TestRow[] = [{ id: 1, status: 'ACTIVE', price: 10 }];
    const editableColumn: GomTableColumn<TestRow> = {
      key: 'price',
      header: 'Price',
      editable: { type: 'number', mode: 'always', min: 0, max: 20, step: 0.5 },
    };
    const events: unknown[] = [];
    fixture.componentRef.setInput('columns', [editableColumn]);
    fixture.componentRef.setInput('rows', editableRows);
    component.cellEdit.subscribe((event) => events.push(event));
    fixture.detectChanges();
    tick();

    expect(fixture.nativeElement.querySelector('.gom-table-cell-editor')).not.toBeNull();
    component.setCellDraft(editableRows[0], editableColumn, '-1');
    component.commitCellEdit(editableRows[0], editableColumn);

    expect(events).toEqual([]);
    expect(component.getCellEditError(editableRows[0], editableColumn)).toContain('at least 0');

    component.setCellDraft(editableRows[0], editableColumn, '10.5');
    component.commitCellEdit(editableRows[0], editableColumn);

    expect(events).toEqual([{
      row: editableRows[0],
      columnKey: 'price',
      previousValue: 10,
      value: 10.5,
    }]);
  }));

  it('supports per-row disabled editing and Escape cancellation', fakeAsync(() => {
    const editableRows: TestRow[] = [
      { id: 1, status: 'LOCKED', price: 10 },
      { id: 2, status: 'ACTIVE', price: 20 },
    ];
    const editableColumn: GomTableColumn<TestRow> = {
      key: 'price',
      header: 'Price',
      editable: { type: 'number', disabled: (row) => row.status === 'LOCKED' },
    };
    let emissionCount = 0;
    fixture.componentRef.setInput('columns', [editableColumn]);
    fixture.componentRef.setInput('rows', editableRows);
    component.cellEdit.subscribe(() => emissionCount += 1);
    fixture.detectChanges();
    tick();

    expect(fixture.nativeElement.querySelectorAll('.gom-table-cell-edit-trigger').length).toBe(1);
    component.startCellEdit(new Event('click'), editableRows[1], editableColumn);
    component.setCellDraft(editableRows[1], editableColumn, '25');
    component.onCellEditorKeydown(
      new KeyboardEvent('keydown', { key: 'Escape' }),
      editableRows[1],
      editableColumn
    );

    expect(component.isCellEditing(editableRows[1], editableColumn)).toBeFalse();
    expect(emissionCount).toBe(0);
    expect(editableRows[1].price).toBe(20);
  }));

  it('commits and moves to the next same-column editor with Alt+ArrowDown', fakeAsync(() => {
    const editableRows: TestRow[] = [
      { id: 1, status: 'ACTIVE', price: 10 },
      { id: 2, status: 'ACTIVE', price: 20 },
    ];
    const editableColumn: GomTableColumn<TestRow> = {
      key: 'price',
      header: 'Price',
      editable: { type: 'number' },
    };
    const events: unknown[] = [];
    fixture.componentRef.setInput('columns', [editableColumn]);
    fixture.componentRef.setInput('rows', editableRows);
    component.cellEdit.subscribe((event) => events.push(event));
    fixture.detectChanges();
    tick();

    component.startCellEdit(new Event('click'), editableRows[0], editableColumn);
    fixture.detectChanges();
    tick();
    const input = fixture.nativeElement.querySelector('.gom-table-cell-editor input') as HTMLInputElement;
    input.value = '15';
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new KeyboardEvent('keydown', {
      key: 'ArrowDown',
      altKey: true,
      bubbles: true,
      cancelable: true,
    }));
    tick(0, { processNewMacroTasksSynchronously: false });
    fixture.detectChanges();
    tick();

    expect(events).toEqual([{
      row: editableRows[0],
      columnKey: 'price',
      previousValue: 10,
      value: 15,
    }]);
    const latestRows = component.rows;
    expect(component.isCellEditing(latestRows[0], editableColumn)).toBeFalse();
    expect(component.isCellEditing(latestRows[1], editableColumn)).toBeTrue();
    expect(document.activeElement).toBe(
      fixture.nativeElement.querySelector('.gom-table-cell-editor input')
    );
  }));

  it('moves to the previous same-column editor with Alt+ArrowUp and skips disabled rows', fakeAsync(() => {
    const editableRows: TestRow[] = [
      { id: 1, status: 'ACTIVE', price: 10 },
      { id: 2, status: 'LOCKED', price: 20 },
      { id: 3, status: 'ACTIVE', price: 30 },
    ];
    const editableColumn: GomTableColumn<TestRow> = {
      key: 'price',
      header: 'Price',
      editable: { type: 'number', disabled: (row) => row.status === 'LOCKED' },
    };
    fixture.componentRef.setInput('columns', [editableColumn]);
    fixture.componentRef.setInput('rows', editableRows);
    fixture.detectChanges();
    tick();

    component.startCellEdit(new Event('click'), editableRows[2], editableColumn);
    fixture.detectChanges();
    tick();
    component.onCellEditorKeydown(
      new KeyboardEvent('keydown', { key: 'ArrowUp', altKey: true }),
      editableRows[2],
      editableColumn
    );
    tick(0, { processNewMacroTasksSynchronously: false });
    fixture.detectChanges();
    tick();

    expect(component.isCellEditing(editableRows[2], editableColumn)).toBeFalse();
    expect(component.isCellEditing(editableRows[1], editableColumn)).toBeFalse();
    expect(component.isCellEditing(editableRows[0], editableColumn)).toBeTrue();
  }));
});
