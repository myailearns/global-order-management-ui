import { Injectable } from '@angular/core';

import {
  GomTableFilterDefinition,
  GomTableFilterValue,
  GomTableClientResult,
  GomTableColumn,
  GomTableQuery,
  GomTableRow,
} from './gom-table.models';

@Injectable({
  providedIn: 'root',
})
export class GomTableService {
  runClientPipeline<T extends GomTableRow>(
    rows: T[],
    columns: GomTableColumn<T>[],
    query: GomTableQuery,
    advancedFilterDefinitions: GomTableFilterDefinition<T>[] = []
  ): GomTableClientResult<T> {
    const searched = this.applySearch(
      rows,
      columns,
      query.searchTerm,
      query.visibleColumnKeys,
      query.globalSearchScope ?? 'visible'
    );
    const filtered = this.applyFilters(searched, query.filters);
    const advancedFiltered = this.applyAdvancedFilters(
      filtered,
      advancedFilterDefinitions,
      query.advancedFilters ?? {}
    );
    const sorted = this.applySort(advancedFiltered, columns, query.sort);
    const paged = this.applyPagination(sorted, query.pageIndex, query.pageSize);

    return {
      rows: paged,
      filteredTotal: sorted.length,
    };
  }

  private applySearch<T extends GomTableRow>(
    rows: T[],
    columns: GomTableColumn<T>[],
    searchTerm: string,
    visibleColumnKeys: string[],
    scope: 'visible' | 'all'
  ): T[] {
    const normalized = searchTerm.trim().toLowerCase();
    if (!normalized) {
      return rows;
    }

    const activeColumns = columns.filter((column) =>
      !column.actionButtons?.length
      && column.searchable !== false
      && (scope === 'all' || visibleColumnKeys.includes(column.key))
    );

    return rows.filter((row) =>
      activeColumns.some((column) => {
        const value = column.searchValue ? column.searchValue(row) : row[column.key];
        return this.stringifyCellValue(value).toLowerCase().includes(normalized);
      })
    );
  }

  private applyAdvancedFilters<T extends GomTableRow>(
    rows: T[],
    definitions: GomTableFilterDefinition<T>[],
    values: Record<string, GomTableFilterValue>
  ): T[] {
    const activeDefinitions = definitions.filter((definition) =>
      this.hasFilterValue(values[definition.key])
    );
    if (!activeDefinitions.length) {
      return rows;
    }

    return rows.filter((row) => activeDefinitions.every((definition) => {
      const filterValue = values[definition.key];
      const rawValue = definition.valueAccessor ? definition.valueAccessor(row) : row[definition.key];
      return this.matchesAdvancedFilter(rawValue, filterValue, definition.type);
    }));
  }

  private matchesAdvancedFilter(
    rawValue: unknown,
    filterValue: GomTableFilterValue,
    type: GomTableFilterDefinition['type']
  ): boolean {
    const cellText = this.stringifyCellValue(rawValue).trim().toLowerCase();

    if (type === 'multi-select') {
      if (Array.isArray(filterValue)) {
        return filterValue.some((value) => value.toLowerCase() === cellText);
      }

      if (typeof filterValue === 'string') {
        return cellText === filterValue.trim().toLowerCase();
      }

      return false;
    }

    if (type === 'date-range' && !Array.isArray(filterValue) && typeof filterValue === 'object') {
      const comparable = this.toDateComparable(rawValue);
      if (!comparable) {
        return false;
      }
      return (!filterValue.from || comparable >= filterValue.from)
        && (!filterValue.to || comparable <= filterValue.to);
    }

    if (typeof filterValue !== 'string') {
      return true;
    }

    const normalizedFilter = filterValue.trim().toLowerCase();
    return type === 'text'
      ? cellText.includes(normalizedFilter)
      : cellText === normalizedFilter;
  }

  private hasFilterValue(value: GomTableFilterValue | undefined): boolean {
    if (typeof value === 'string') {
      return value.trim().length > 0;
    }
    if (Array.isArray(value)) {
      return value.length > 0;
    }
    return !!value && (!!value.from || !!value.to);
  }

  private toDateComparable(value: unknown): string {
    if (value instanceof Date && !Number.isNaN(value.getTime())) {
      return value.toISOString().slice(0, 10);
    }
    if (typeof value !== 'string' && typeof value !== 'number') {
      return '';
    }
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? '' : parsed.toISOString().slice(0, 10);
  }

  private applyFilters<T extends GomTableRow>(
    rows: T[],
    filters: Record<string, string>
  ): T[] {
    const filterEntries = Object.entries(filters).filter(([, value]) => value.trim() !== '');
    if (!filterEntries.length) {
      return rows;
    }

    return rows.filter((row) =>
      filterEntries.every(([key, filterValue]) => {
        const cellText = this.stringifyCellValue(row[key]).toLowerCase();
        return cellText.includes(filterValue.trim().toLowerCase());
      })
    );
  }

  private applySort<T extends GomTableRow>(
    rows: T[],
    columns: GomTableColumn<T>[],
    sort: GomTableQuery['sort']
  ): T[] {
    if (!sort.key || !sort.direction) {
      return rows;
    }

    const directionFactor = sort.direction === 'asc' ? 1 : -1;
    const column = columns.find((item) => item.key === sort.key);

    return [...rows].sort((first, second) => {
      const firstValue = column?.sortValue ? column.sortValue(first) : first[sort.key];
      const secondValue = column?.sortValue ? column.sortValue(second) : second[sort.key];

      const firstNumeric = Number(firstValue);
      const secondNumeric = Number(secondValue);

      const bothNumeric = Number.isFinite(firstNumeric) && Number.isFinite(secondNumeric);

      if (bothNumeric) {
        return (firstNumeric - secondNumeric) * directionFactor;
      }

      const firstText = this.stringifyCellValue(firstValue).toLowerCase();
      const secondText = this.stringifyCellValue(secondValue).toLowerCase();

      if (firstText < secondText) {
        return -1 * directionFactor;
      }
      if (firstText > secondText) {
        return 1 * directionFactor;
      }
      return 0;
    });
  }

  private applyPagination<T extends GomTableRow>(rows: T[], pageIndex: number, pageSize: number): T[] {
    const start = pageIndex * pageSize;
    return rows.slice(start, start + pageSize);
  }

  private stringifyCellValue(value: unknown): string {
    if (value === null || value === undefined) {
      return '';
    }
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      return String(value);
    }
    if (value instanceof Date) {
      return value.toISOString();
    }
    return JSON.stringify(value);
  }
}
