export type GomTableRow = Record<string, unknown>;

export type GomTableAlign = 'left' | 'center' | 'right';

export type GomTableTextMode = 'truncate' | 'wrap' | 'expand';

export type GomSortDirection = 'asc' | 'desc' | '';

export type GomTableActionVariant = 'primary' | 'secondary' | 'danger';
export type GomTableEditMode = 'click' | 'always';
export type GomTableEditorType = 'text' | 'number';
export type GomTableGlobalSearchScope = 'visible' | 'all';
export type GomTableFilterType = 'text' | 'select' | 'multi-select' | 'date' | 'date-range';
export type GomTableFilterPlacement = 'panel' | 'toolbar' | 'both';
export type GomTableFilterValue = string | string[] | { from: string; to: string };
export type GomTableMobileFilterControl = 'checkboxes' | 'chips' | 'radio' | 'default';

export interface GomTableFilterOption {
  label: string;
  value: string;
  count?: number;
}

export interface GomTableFilterNavigationOption extends GomTableFilterOption {
  count?: number;
  disabled?: boolean;
}

export interface GomTableFilterNavigationRow<T extends GomTableRow = GomTableRow> {
  key: keyof T & string;
  label?: string;
  options?: GomTableFilterNavigationOption[];
  optionSource?: 'static' | 'rows';
  valueAccessor?: (row: T) => unknown;
  allOption?: GomTableFilterNavigationOption | false;
  showCounts?: boolean;
}

export interface GomTableFilterNavigationChange {
  key: string;
  value: string;
}

export interface GomTableFilterDefinition<T extends GomTableRow = GomTableRow> {
  key: keyof T & string;
  label: string;
  type: GomTableFilterType;
  placeholder?: string;
  options?: GomTableFilterOption[];
  optionSource?: 'static' | 'rows';
  placement?: GomTableFilterPlacement;
  searchable?: boolean;
  valueAccessor?: (row: T) => unknown;
  mobileControl?: GomTableMobileFilterControl;
}

export interface GomTableMobileCardField<T extends GomTableRow = GomTableRow> {
  key: keyof T & string;
  label?: string;
  width?: 'half' | 'full';
  hideWhenEmpty?: boolean;
  format?: (value: unknown, row: T) => string;
}

export interface GomTableMobileCardHeader<T extends GomTableRow = GomTableRow> {
  titleKey?: keyof T & string;
  subtitleKeys?: Array<keyof T & string>;
  statusKey?: keyof T & string;
  overflowActionKeys?: string[];
}

export interface GomTableMobileCardBody<T extends GomTableRow = GomTableRow> {
  visibleFields?: GomTableMobileCardField<T>[];
  expandableFields?: GomTableMobileCardField<T>[];
  defaultExpanded?: boolean;
}

export interface GomTableMobileCardFooter<T extends GomTableRow = GomTableRow> {
  primaryActionKeys?: string[];
  secondaryActionKeys?: string[];
  showPrimaryActionLabels?: boolean;
  showDetailsToggle?: boolean;
  expandLabel?: string;
  collapseLabel?: string;
}

export interface GomTableMobileCardConfig<T extends GomTableRow = GomTableRow> {
  header?: GomTableMobileCardHeader<T>;
  body?: GomTableMobileCardBody<T>;
  footer?: GomTableMobileCardFooter<T>;
}

export interface GomTableAppliedFilter {
  key: string;
  label: string;
  displayValue: string;
}
export type GomChipTone =
  | 'neutral'
  | 'info'
  | 'warning'
  | 'success'
  | 'danger'
  | 'pending'
  | 'progress'
  | 'shipped'
  | 'delivered'
  | 'cancelled';

export interface GomTableActionButton<T extends GomTableRow = GomTableRow> {
  label: string | ((row: T) => string);
  icon?: string | ((row: T) => string);
  actionKey: string;
  variant?: GomTableActionVariant;
  disabled?: (row: T) => boolean;
  disabledTooltip?: string | ((row: T) => string);
  subActions?: GomTableActionButton<T>[];
}

export interface GomTableActionOverflowMenu<T extends GomTableRow = GomTableRow> {
  actionKeys: string[];
  triggerIcon?: string;
  triggerAriaLabel?: string;
  triggerButtonTitle?: string;
  backButtonText?: string;
}

export interface GomTableBulkAction<T extends GomTableRow = GomTableRow> {
  actionKey: string;
  label: string;
  icon?: string;
  variant?: GomTableActionVariant;
  visible?: (selectedRows: T[]) => boolean;
  disabled?: (selectedRows: T[]) => boolean;
  disabledTooltip?: string | ((selectedRows: T[]) => string);
}

export interface GomTableBulkActionEvent<T extends GomTableRow = GomTableRow> {
  actionKey: string;
  selectedRows: T[];
  selectedRowKeys: string[];
}

export interface GomTableEditableConfig<T extends GomTableRow = GomTableRow> {
  type?: GomTableEditorType;
  mode?: GomTableEditMode;
  disabled?: (row: T) => boolean;
  min?: number;
  max?: number;
  step?: number;
}

export interface GomTableCellEditEvent<T extends GomTableRow = GomTableRow> {
  row: T;
  columnKey: keyof T & string;
  previousValue: unknown;
  value: string | number;
}

export interface GomTableSortState {
  key: string;
  direction: GomSortDirection;
}

export interface GomTableColumn<T extends GomTableRow = GomTableRow> {
  key: keyof T & string;
  header: string;
  sortable?: boolean;
  sortValue?: (row: T) => unknown;
  filterable?: boolean;
  width?: string;
  headerAlign?: GomTableAlign;
  cellAlign?: GomTableAlign;
  textMode?: GomTableTextMode;
  format?: (value: unknown, row: T) => string;
  tooltip?: (value: unknown, row: T) => string;
  cellClass?: (value: unknown, row: T) => string;
  hiddenByDefault?: boolean;
  hideable?: boolean;
  searchable?: boolean;
  searchValue?: (row: T) => unknown;
  editable?: boolean | GomTableEditableConfig<T>;
  clickActionKey?: string | ((row: T) => string | null);
  clickActionIcon?: string | ((row: T) => string | null | undefined);
  chipTone?: GomChipTone | ((value: unknown, row: T) => GomChipTone);
  actionButtons?: GomTableActionButton<T>[];
  actionOverflowMenu?: GomTableActionOverflowMenu<T> | null;
}

export interface GomTableQuery {
  searchTerm: string;
  sort: GomTableSortState;
  pageIndex: number;
  pageSize: number;
  filters: Record<string, string>;
  visibleColumnKeys: string[];
  advancedFilters?: Record<string, GomTableFilterValue>;
  globalSearchScope?: GomTableGlobalSearchScope;
}

export interface GomTablePageChangeEvent {
  pageIndex: number;
  pageSize: number;
}

export interface GomTableClientResult<T extends GomTableRow = GomTableRow> {
  rows: T[];
  filteredTotal: number;
}
