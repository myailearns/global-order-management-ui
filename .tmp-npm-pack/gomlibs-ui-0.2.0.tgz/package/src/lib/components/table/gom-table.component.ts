import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  AfterViewInit,
  HostListener,
  HostBinding,
  Input,
  OnInit,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild,
  inject,
} from '@angular/core';
import { FormsModule } from '@angular/forms';

import {
  GomChipTone,
  GomTableFilterDefinition,
  GomTableAppliedFilter,
  GomTableFilterNavigationChange,
  GomTableFilterNavigationOption,
  GomTableFilterNavigationRow,
  GomTableFilterValue,
  GomTableGlobalSearchScope,
  GomSortDirection,
  GomTableActionButton,
  GomTableAlign,
  GomTableBulkAction,
  GomTableBulkActionEvent,
  GomTableCellEditEvent,
  GomTableColumn,
  GomTableActionOverflowMenu,
  GomTableEditableConfig,
  GomTablePageChangeEvent,
  GomTableQuery,
  GomTableRow,
  GomTableSortState,
  GomTableTextMode,
  GomTableMobileCardConfig,
  GomTableMobileCardField,
} from './gom-table.models';
import { GomButtonComponent, GomInputComponent, GomSelectComponent, GomSelectOption } from '../form-controls';
import { GomCardComponent } from '../card';
import { GomChipComponent } from '../chip';
import { GomModalComponent } from '../modal';
import { MainMenuList, MenuComponent, MenuList } from '../menu';
import { GomTableService } from './gom-table.service';

@Component({
  selector: 'gom-lib-table',
  standalone: true,
  imports: [CommonModule, FormsModule, GomInputComponent, GomButtonComponent, GomSelectComponent, GomCardComponent, GomChipComponent, GomModalComponent, MenuComponent],
  templateUrl: './gom-table.component.html',
  styleUrl: './gom-table.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '[class.gom-table-mobile-card]': 'mobileCardView',
    '[class.gom-table-mobile-cards-active]': 'isMobileCardsActive',
    '[class.gom-table-mobile-table-active]': 'isMobileTableActive',
  },
})
export class GomTableComponent<T extends GomTableRow = GomTableRow> implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  @Input() columns: GomTableColumn<T>[] = [];
  @Input() rows: T[] = [];
  @Input() loading = false;
  @Input() dataMode: 'client' | 'server' = 'client';
  @Input() totalItems = 0;
  @Input() pageSize = 10;
  @Input() pageIndex = 0;
  @Input() pageSizeOptions: number[] = [5, 10, 20, 50, 100];
  @Input() showPagination = true;
  @Input() searchPlaceholder = 'Search...';
  @Input() emptyMessage = 'No records found.';
  @Input() mobileCardView = false;
  @Input() mobileCardFields: string[] = [];
  @Input() mobileSortKeys: string[] = [];
  @Input() mobileCardClickable = false;
  @Input() mobileCardConfig: GomTableMobileCardConfig<T> | null = null;
  @Input() mobilePaginationMode: 'pages' | 'load-more' = 'pages';
  @Input() mobileAutoLoadMore = false;
  @Input() mobileLoadMoreStrategy: 'emit' | 'page-query' = 'emit';
  @Input() bodyViewportRows: number | null = null;
  @Input() enableRowSelection = false;
  @Input() bulkActions: GomTableBulkAction<T>[] = [];
  @Input() bulkActionBusyKey: string | null = null;
  @Input() selectionItemLabel = 'row';
  @Input() showSearch = true;
  @Input() globalSearchScope: GomTableGlobalSearchScope = 'visible';
  @Input() searchDebounceMs = 300;
  @Input() showFilterButton = true;
  @Input() showClearFilterButton = false;
  @Input() advancedFilterDefinitions: GomTableFilterDefinition<T>[] = [];
  @Input() filterNavigationRows: GomTableFilterNavigationRow<T>[] = [];
  @Input() enableColumnSearch = true;
  @Input() showColumnSearchInitially = false;
  @Input() enableColumnVisibility = true;
  @Input() showExport = false;
  @Input() showInlineEditBanner = false;
  @Input() inlineEditBannerCount = 0;
  @Input() inlineEditBannerSummary = 'You have unsaved changes';
  @Input() inlineEditBannerDetail = '';
  @Input() inlineEditBannerSaveLabel = 'Save All';
  @Input() inlineEditBannerDiscardLabel = 'Discard All';
  @Input() inlineEditBannerReviewLabel = 'Review Changes';
  @Input() inlineEditBannerSaving = false;

  @Output() queryChange = new EventEmitter<GomTableQuery>();
  @Output() pageChange = new EventEmitter<GomTablePageChangeEvent>();
  @Output() sortChange = new EventEmitter<GomTableSortState>();
  @Output() filterChange = new EventEmitter<Record<string, string>>();
  @Output() filterNavigationChange = new EventEmitter<GomTableFilterNavigationChange>();
  @Output() columnVisibilityChange = new EventEmitter<string[]>();
  @Output() rowAction = new EventEmitter<{ actionKey: string; row: T }>();
  @Output() cellEdit = new EventEmitter<GomTableCellEditEvent<T>>();
  @Output() rowClick = new EventEmitter<T>();
  @Output() selectedRowsChange = new EventEmitter<T[]>();
  @Output() bulkAction = new EventEmitter<GomTableBulkActionEvent<T>>();
  @Output() loadMore = new EventEmitter<GomTablePageChangeEvent>();
  @Output() exportClick = new EventEmitter<void>();
  @Output() inlineEditDiscardAll = new EventEmitter<void>();
  @Output() inlineEditSaveAll = new EventEmitter<void>();
  @Output() inlineEditReviewChanges = new EventEmitter<void>();

  @HostBinding('style.--gom-table-body-max-height')
  get tableBodyMaxHeight(): string | null {
    if (!Number.isFinite(Number(this.bodyViewportRows)) || Number(this.bodyViewportRows) <= 0) {
      return null;
    }

    return `${Math.trunc(Number(this.bodyViewportRows)) * 3.25}rem`;
  }

  displayedRows: T[] = [];
  searchTerm = '';
  filters: Record<string, string> = {};
  sortState: GomTableSortState = { key: '', direction: '' };
  visibleColumnKeys = new Set<string>();
  columnPanelOpen = false;
  filtersVisible = false;
  toolbarOptionsOpen = false;
  advancedFilterModalOpen = false;
  advancedFilters: Record<string, GomTableFilterValue> = {};
  draftAdvancedFilters: Record<string, GomTableFilterValue> = {};
  filteredTotal = 0;
  selectedRowKeys = new Set<string>();
  mobileViewMode: 'cards' | 'table' = 'cards';
  isMobileViewport = false;
  submenuOpenKey: string | null = null;
  submenuPosition: Record<string, string> | null = null;
  navigationOverflowOpenKey: string | null = null;
  navigationVisibleOptionCounts: Record<string, number> = {};
  mobileTableOptionsOpen = false;
  mobileRowActionsOpen = false;
  mobileRowActionTarget: T | null = null;
  @ViewChild('mobileLoadMoreSentinel') mobileLoadMoreSentinel?: ElementRef<HTMLElement>;
  private readonly mobileCardExpandedRowKeys = new Set<string>();
  private mobileLoadMoreObserver: IntersectionObserver | null = null;
  private mobileLoadMoreSentinelInView = false;
  private autoLoadMoreCooldownUntil = 0;
  private accumulatedServerRows: T[] = [];
  private lastAccumulatedPageIndex = 0;
  private lastSyncedServerRowsRef: T[] | null = null;
  private lastSyncedServerPageIndex = -1;

  private readonly tableService = inject(GomTableService);
  private readonly host = inject(ElementRef<HTMLElement>);
  private readonly changeDetector = inject(ChangeDetectorRef);
  private searchDebounceTimer: ReturnType<typeof setTimeout> | null = null;
  private navigationResizeObserver: ResizeObserver | null = null;
  private readonly navigationOptionWidths = new Map<string, number[]>();
  private navigationLayoutTimer: ReturnType<typeof setTimeout> | null = null;
  private cellEditStates = new WeakMap<T, Map<string, { previousValue: unknown; draft: string; error: string }>>();
  private pendingCellNavigation: { rowKey: string; columnKey: string } | null = null;
  private pendingCellNavigationTimer: ReturnType<typeof setTimeout> | null = null;

  ngOnInit(): void {
    this.updateViewportMode();
    this.filtersVisible = this.enableColumnSearch && this.showColumnSearchInitially;
  }

  ngAfterViewInit(): void {
    this.observeFilterNavigationRows();
    this.scheduleFilterNavigationLayout();
    this.syncMobileLoadMoreObserver();
  }

  ngOnDestroy(): void {
    if (this.searchDebounceTimer) {
      clearTimeout(this.searchDebounceTimer);
    }
    if (this.navigationLayoutTimer) {
      clearTimeout(this.navigationLayoutTimer);
    }
    if (this.pendingCellNavigationTimer) {
      clearTimeout(this.pendingCellNavigationTimer);
    }
    this.navigationResizeObserver?.disconnect();
    this.mobileLoadMoreObserver?.disconnect();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['columns']) {
      this.initializeVisibleColumns();
    }

    if (changes['rows'] || changes['dataMode']) {
      this.clearSelection();
      this.mobileCardExpandedRowKeys.clear();
      this.cellEditStates = new WeakMap<T, Map<string, { previousValue: unknown; draft: string; error: string }>>();
      if (changes['dataMode']) {
        this.accumulatedServerRows = [];
        this.lastAccumulatedPageIndex = 0;
        this.lastSyncedServerRowsRef = null;
        this.lastSyncedServerPageIndex = -1;
      }
    }

    if (changes['filterNavigationRows'] || changes['rows']) {
      this.navigationOptionWidths.clear();
      this.navigationVisibleOptionCounts = {};
      this.scheduleFilterNavigationLayout();
    }

    if (this.dataMode === 'client') {
      this.runClientMode();
    } else {
      this.syncServerModeRows();

      if (changes['dataMode']?.firstChange || changes['columns']?.firstChange) {
        this.queryChange.emit(this.buildQuery());
      }
    }

    if (this.pendingCellNavigation) {
      this.schedulePendingCellNavigation();
    }

    if (
      changes['mobileCardView']
      || changes['mobilePaginationMode']
      || changes['mobileAutoLoadMore']
      || changes['showPagination']
    ) {
      setTimeout(() => {
        this.syncMobileLoadMoreObserver();
      });
    }
  }

  get showMobileViewToggle(): boolean {
    return this.mobileCardView && this.isMobileViewport;
  }

  get isMobileCardsActive(): boolean {
    return this.mobileCardView && this.isMobileViewport && this.mobileViewMode === 'cards';
  }

  get isMobileTableActive(): boolean {
    return this.mobileCardView && this.isMobileViewport && this.mobileViewMode === 'table';
  }

  get visibleColumns(): GomTableColumn<T>[] {
    return this.columns.filter((column) => this.visibleColumnKeys.has(column.key));
  }

  get mobileCardColumns(): GomTableColumn<T>[] {
    if (this.mobileCardFields.length > 0) {
      return this.mobileCardFields
        .map((key) => this.columns.find((column) => column.key === key) ?? null)
        .filter((column): column is GomTableColumn<T> => !!column && !this.hasActionButtons(column));
    }

    return this.visibleColumns.filter((column) => !this.hasActionButtons(column));
  }

  get mobileSortColumns(): GomTableColumn<T>[] {
    const sortableColumns = this.columns.filter((column) => column.sortable);
    if (this.mobileSortKeys.length === 0) {
      return sortableColumns;
    }

    const columnsByKey = new Map(sortableColumns.map((column) => [column.key, column]));
    return this.mobileSortKeys
      .map((key) => columnsByKey.get(key))
      .filter((column): column is GomTableColumn<T> => !!column);
  }

  get mobileCardActionColumn(): GomTableColumn<T> | null {
    const visibleActionColumn = this.visibleColumns.find((column) => this.hasActionButtons(column));
    if (visibleActionColumn) {
      return visibleActionColumn;
    }

    return this.columns.find((column) => this.hasActionButtons(column)) ?? null;
  }

  get hasInlineFilters(): boolean {
    return this.enableColumnSearch && this.filtersVisible && this.visibleColumns.some((column) => column.filterable);
  }

  get showToolbarOptions(): boolean {
    return this.enableColumnSearch || this.enableColumnVisibility || this.showExport;
  }

  get toolbarOptionsMenuList(): MenuList {
    const mainMenu: MainMenuList[] = [];

    if (this.showExport) {
      mainMenu.push({
        title: 'Export',
        icon: 'ri-download-2-line',
        clickEvent: () => this.exportClick.emit(),
      });
    }

    if (this.enableColumnSearch) {
      mainMenu.push({
        title: this.filtersVisible ? 'Hide column search' : 'Show column search',
        icon: this.filtersVisible ? 'ri-checkbox-circle-fill' : 'ri-search-line',
        clickEvent: () => this.toggleFilters(),
      });
    }

    if (this.enableColumnVisibility) {
      mainMenu.push({
        title: 'Manage columns',
        icon: 'ri-layout-column-line',
        clickEvent: () => this.toggleColumnPanel(),
      });
    }

    return {
      mainMenu,
      portalMenu: [],
    };
  }

  get panelFilterDefinitions(): GomTableFilterDefinition<T>[] {
    return this.advancedFilterDefinitions.filter((definition) =>
      (definition.placement ?? 'panel') !== 'toolbar'
    );
  }

  get toolbarFilterDefinitions(): GomTableFilterDefinition<T>[] {
    return this.advancedFilterDefinitions.filter((definition) => {
      const placement = definition.placement ?? 'panel';
      return placement === 'toolbar' || placement === 'both';
    });
  }

  get activeAdvancedFilterCount(): number {
    return Object.values(this.advancedFilters).filter((value) => this.hasFilterValue(value)).length;
  }

  get activeColumnFilterCount(): number {
    return Object.values(this.filters).filter((value) => value.trim().length > 0).length;
  }

  get activeFilterCount(): number {
    return this.activeAdvancedFilterCount + this.activeColumnFilterCount;
  }

  get draftAdvancedFilterCount(): number {
    return Object.values(this.draftAdvancedFilters).filter((value) => this.hasFilterValue(value)).length;
  }

  get appliedFilterChips(): GomTableAppliedFilter[] {
    const advanced = Object.entries(this.advancedFilters)
      .filter(([, value]) => this.hasFilterValue(value))
      .map(([key, value]) => {
        const definition = this.advancedFilterDefinitions.find((item) => item.key === key);
        return {
          key: `advanced:${key}`,
          label: definition?.label ?? key,
          displayValue: this.formatFilterValue(definition, value),
        };
      });
    const columns = Object.entries(this.filters)
      .filter(([, value]) => value.trim().length > 0)
      .map(([key, value]) => ({
        key: `column:${key}`,
        label: this.columns.find((column) => column.key === key)?.header ?? key,
        displayValue: value,
      }));
    return [...advanced, ...columns];
  }

  get mobileSortLabel(): string {
    if (!this.sortState.key || !this.sortState.direction) {
      return 'Default';
    }
    const column = this.columns.find((item) => item.key === this.sortState.key);
    return `${column?.header ?? this.sortState.key} ${this.sortState.direction === 'asc' ? '↑' : '↓'}`;
  }

  get mobileSortButtonLabel(): string {
    if (!this.sortState.key || !this.sortState.direction) {
      return 'Default';
    }
    const column = this.columns.find((item) => item.key === this.sortState.key);
    const label = column?.header ?? 'Default';
    const maxLength = 16;
    return label.length > maxLength ? `${label.slice(0, maxLength).trimEnd()}...` : label;
  }

  getFilterNavigationOptions(row: GomTableFilterNavigationRow<T>): GomTableFilterNavigationOption[] {
    const options = (row.optionSource ?? 'static') === 'rows'
      ? this.getRowDerivedFilterNavigationOptions(row)
      : row.options ?? [];
    const allOption = row.allOption === false
      ? []
      : [{
          ...(row.allOption ?? { label: 'All', value: '' }),
          count: row.allOption?.count ?? ((row.optionSource === 'rows' && row.showCounts) ? this.rows.length : undefined),
        }];
    return [...allOption, ...options];
  }

  private getRowDerivedFilterNavigationOptions(
    navigationRow: GomTableFilterNavigationRow<T>
  ): GomTableFilterNavigationOption[] {
    const values = new Map<string, number>();
    for (const row of this.rows) {
      const rawValue = navigationRow.valueAccessor
        ? navigationRow.valueAccessor(row)
        : row[navigationRow.key];
      const value = this.stringifyCellValue(rawValue).trim();
      if (value) {
        values.set(value, (values.get(value) ?? 0) + 1);
      }
    }

    return [...values].map(([value, count]) => ({
      label: value,
      value,
      count,
    }));
  }

  getVisibleFilterNavigationOptions(row: GomTableFilterNavigationRow<T>): GomTableFilterNavigationOption[] {
    const options = this.getFilterNavigationOptions(row);
    return options.slice(0, this.navigationVisibleOptionCounts[row.key] ?? options.length);
  }

  getOverflowFilterNavigationOptions(row: GomTableFilterNavigationRow<T>): GomTableFilterNavigationOption[] {
    const options = this.getFilterNavigationOptions(row);
    return options.slice(this.navigationVisibleOptionCounts[row.key] ?? options.length);
  }

  isFilterNavigationOptionActive(row: GomTableFilterNavigationRow<T>, option: GomTableFilterNavigationOption): boolean {
    return this.getFilterString(this.advancedFilters, row.key) === option.value;
  }

  hasActiveOverflowFilterNavigationOption(row: GomTableFilterNavigationRow<T>): boolean {
    return this.getOverflowFilterNavigationOptions(row).some((option) =>
      this.isFilterNavigationOptionActive(row, option)
    );
  }

  selectFilterNavigationOption(
    row: GomTableFilterNavigationRow<T>,
    option: GomTableFilterNavigationOption
  ): void {
    if (option.disabled || this.isFilterNavigationOptionActive(row, option)) {
      this.navigationOverflowOpenKey = null;
      return;
    }
    this.navigationOverflowOpenKey = null;
    this.setQuickFilterValue(row.key, option.value);
    this.filterNavigationChange.emit({ key: row.key, value: option.value });
  }

  toggleFilterNavigationOverflow(event: Event, rowKey: string): void {
    event.stopPropagation();
    this.navigationOverflowOpenKey = this.navigationOverflowOpenKey === rowKey ? null : rowKey;
  }

  onFilterNavigationKeydown(event: KeyboardEvent, rowKey: string): void {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) {
      return;
    }
    const row = this.findFilterNavigationElement('data-filter-navigation-row', rowKey);
    const buttons = Array.from(row?.querySelectorAll<HTMLButtonElement>('button:not(:disabled)') ?? []);
    const currentIndex = buttons.indexOf(event.target as HTMLButtonElement);
    if (currentIndex < 0 || !buttons.length) {
      return;
    }
    event.preventDefault();
    let nextIndex: number;
    if (event.key === 'Home') {
      nextIndex = 0;
    } else if (event.key === 'End') {
      nextIndex = buttons.length - 1;
    } else {
      const offset = event.key === 'ArrowRight' ? 1 : -1;
      nextIndex = (currentIndex + offset + buttons.length) % buttons.length;
    }
    buttons[nextIndex]?.focus();
  }

  get pageSizeSelectOptions(): GomSelectOption[] {
    return this.pageSizeOptions.map((option) => ({
      value: String(option),
      label: `Show ${option}`,
    }));
  }

  get skeletonRows(): number[] {
    const parsedPageSize = Number(this.pageSize);
    const rowCount = Number.isFinite(parsedPageSize)
      ? Math.max(1, Math.min(100, Math.trunc(parsedPageSize)))
      : 10;

    return Array.from({ length: rowCount }, (_, index) => index);
  }

  get pageSizeModel(): string {
    return String(this.pageSize);
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.paginationTotal / this.pageSize));
  }

  get paginationTotal(): number {
    return Math.max(0, this.dataMode === 'client' ? this.filteredTotal : this.totalItems);
  }

  get paginationRangeStart(): number {
    if (this.isMobileLoadMoreActive()) {
      return this.paginationTotal === 0 ? 0 : 1;
    }
    return this.paginationTotal === 0 ? 0 : (this.pageIndex * this.pageSize) + 1;
  }

  get paginationRangeEnd(): number {
    if (this.isMobileLoadMoreActive()) {
      return Math.min(this.displayedRows.length, this.paginationTotal);
    }
    return Math.min((this.pageIndex + 1) * this.pageSize, this.paginationTotal);
  }

  get paginationItems(): Array<number | 'ellipsis-start' | 'ellipsis-end'> {
    const total = this.totalPages;
    const current = this.pageIndex + 1;
    if (total <= 7) {
      return Array.from({ length: total }, (_, index) => index + 1);
    }
    if (current <= 3) {
      const end = Math.max(3, current + 1);
      return [
        ...Array.from({ length: end }, (_, index) => index + 1),
        'ellipsis-end',
        total,
      ];
    }
    if (current >= total - 2) {
      const start = Math.min(total - 2, current - 1);
      return [
        1,
        'ellipsis-start',
        ...Array.from({ length: total - start + 1 }, (_, index) => start + index),
      ];
    }
    return [1, 'ellipsis-start', current - 1, current, current + 1, 'ellipsis-end', total];
  }

  getActionLabel(action: GomTableActionButton<T>, row: T): string {
    return typeof action.label === 'function' ? action.label(row) : action.label;
  }

  getActionIcon(action: GomTableActionButton<T>, row: T): string | null {
    if (!action.icon) {
      return null;
    }
    return typeof action.icon === 'function' ? action.icon(row) : action.icon;
  }

  isActionDisabled(action: GomTableActionButton<T>, row: T): boolean {
    return action.disabled ? action.disabled(row) : false;
  }

  getActionTitle(action: GomTableActionButton<T>, row: T): string {
    if (this.isActionDisabled(action, row)) {
      if (action.disabledTooltip) {
        return typeof action.disabledTooltip === 'function'
          ? action.disabledTooltip(row)
          : action.disabledTooltip;
      }
      return 'You do not have permission for this action';
    }

    return this.getActionLabel(action, row);
  }

  get canGoPrevious(): boolean {
    return this.pageIndex > 0;
  }

  get canGoNext(): boolean {
    if (this.isMobileLoadMoreActive()) {
      return this.displayedRows.length < this.paginationTotal;
    }
    return this.pageIndex + 1 < this.totalPages;
  }

  get hasSelectedRows(): boolean {
    return this.selectedRowKeys.size > 0;
  }

  get selectedRowCount(): number {
    return this.selectedRowKeys.size;
  }

  get selectedRows(): T[] {
    return this.rows.filter((row, rowIndex) => this.selectedRowKeys.has(this.getRowKey(row, rowIndex)));
  }

  get visibleBulkActions(): GomTableBulkAction<T>[] {
    const selectedRows = this.selectedRows;
    return this.bulkActions.filter((action) => action.visible ? action.visible(selectedRows) : true);
  }

  get selectionSummary(): string {
    const label = this.selectedRowCount === 1 ? this.selectionItemLabel : `${this.selectionItemLabel}s`;
    return `${this.selectedRowCount} ${label} selected`;
  }

  isBulkActionDisabled(action: GomTableBulkAction<T>): boolean {
    return Boolean(this.bulkActionBusyKey) || (action.disabled ? action.disabled(this.selectedRows) : false);
  }

  getBulkActionTitle(action: GomTableBulkAction<T>): string {
    if (!this.isBulkActionDisabled(action)) {
      return action.label;
    }
    if (!action.disabledTooltip) {
      return this.bulkActionBusyKey ? 'Another bulk action is in progress' : action.label;
    }
    return typeof action.disabledTooltip === 'function'
      ? action.disabledTooltip(this.selectedRows)
      : action.disabledTooltip;
  }

  triggerBulkAction(action: GomTableBulkAction<T>): void {
    if (!this.hasSelectedRows || this.isBulkActionDisabled(action)) {
      return;
    }
    this.bulkAction.emit({
      actionKey: action.actionKey,
      selectedRows: this.selectedRows,
      selectedRowKeys: Array.from(this.selectedRowKeys),
    });
  }

  clearSelectedRows(): void {
    this.clearSelection();
  }

  toggleColumnPanel(): void {
    this.columnPanelOpen = !this.columnPanelOpen;
    this.toolbarOptionsOpen = false;
  }

  toggleFilters(): void {
    if (!this.enableColumnSearch) {
      return;
    }
    this.filtersVisible = !this.filtersVisible;
    this.toolbarOptionsOpen = false;
  }

  toggleToolbarOptions(event?: Event): void {
    event?.stopPropagation();
    this.toolbarOptionsOpen = !this.toolbarOptionsOpen;
  }

  openAdvancedFilters(): void {
    if (!this.panelFilterDefinitions.length) {
      return;
    }
    this.draftAdvancedFilters = this.cloneFilterValues(this.advancedFilters);
    this.advancedFilterModalOpen = true;
  }

  closeAdvancedFilters(): void {
    this.advancedFilterModalOpen = false;
    this.draftAdvancedFilters = this.cloneFilterValues(this.advancedFilters);
  }

  applyAdvancedFilters(): void {
    this.advancedFilters = this.cloneFilterValues(this.draftAdvancedFilters);
    this.advancedFilterModalOpen = false;
    this.pageIndex = 0;
    this.refresh();
  }

  clearDraftAdvancedFilters(): void {
    this.draftAdvancedFilters = {};
  }

  clearAdvancedFilters(): void {
    this.advancedFilters = {};
    this.draftAdvancedFilters = {};
    this.pageIndex = 0;
    this.refresh();
  }

  clearAllFilters(): void {
    this.advancedFilters = {};
    this.draftAdvancedFilters = {};
    this.filters = {};
    this.pageIndex = 0;
    this.filterChange.emit(this.filters);
    this.refresh();
    this.changeDetector.markForCheck();
  }

  clearAllQueryFilters(): void {
    this.searchTerm = '';
    this.advancedFilters = {};
    this.draftAdvancedFilters = {};
    this.filters = {};
    this.pageIndex = 0;
    this.filterChange.emit(this.filters);
    this.refresh();
    this.changeDetector.markForCheck();
  }

  setQueryFilters(filters: Record<string, GomTableFilterValue>, clearSearch = true): void {
    if (clearSearch) {
      this.searchTerm = '';
    }
    this.advancedFilters = this.cloneFilterValues(filters);
    this.draftAdvancedFilters = this.cloneFilterValues(this.advancedFilters);
    this.filters = {};
    this.pageIndex = 0;
    this.filterChange.emit(this.filters);
    this.refresh();
    this.changeDetector.markForCheck();
  }

  removeAppliedFilter(chipKey: string): void {
    const separator = chipKey.indexOf(':');
    const type = chipKey.slice(0, separator);
    const key = chipKey.slice(separator + 1);
    if (type === 'advanced') {
      const { [key]: _removed, ...remaining } = this.advancedFilters;
      this.advancedFilters = remaining;
      this.draftAdvancedFilters = this.cloneFilterValues(remaining);
    } else {
      const { [key]: _removed, ...remaining } = this.filters;
      this.filters = remaining;
      this.filterChange.emit(this.filters);
    }
    this.pageIndex = 0;
    this.refresh();
  }

  toggleColumn(columnKey: string): void {
    const column = this.columns.find((item) => item.key === columnKey);
    if (!column || column.hideable === false) {
      return;
    }
    if (this.visibleColumnKeys.has(columnKey)) {
      const visibleHideableColumns = this.visibleColumns.filter((item) => item.hideable !== false);
      if (visibleHideableColumns.length === 1) {
        return;
      }
      this.visibleColumnKeys.delete(columnKey);
    } else {
      this.visibleColumnKeys.add(columnKey);
    }

    this.pageIndex = 0;
    this.columnVisibilityChange.emit([...this.visibleColumnKeys]);
    this.refresh();
  }

  setSort(column: GomTableColumn<T>): void {
    if (!column.sortable) {
      return;
    }

    this.sortState = {
      key: column.key,
      direction: this.getNextSortDirection(column.key),
    };

    if (this.sortState.direction === '') {
      this.sortState.key = '';
    }

    this.pageIndex = 0;
    this.sortChange.emit(this.sortState);
    this.refresh();
  }

  setSearchTerm(term: string): void {
    this.searchTerm = term;
    this.pageIndex = 0;
    if (this.searchDebounceTimer) {
      clearTimeout(this.searchDebounceTimer);
    }
    if (this.searchDebounceMs <= 0) {
      this.refresh();
      return;
    }
    this.searchDebounceTimer = setTimeout(() => {
      this.searchDebounceTimer = null;
      this.refresh();
    }, this.searchDebounceMs);
  }

  clearSearch(): void {
    this.setSearchTerm('');
  }

  setFilter(columnKey: string, value: string): void {
    this.filters[columnKey] = value;
    this.pageIndex = 0;
    this.filterChange.emit(this.filters);
    this.refresh();
  }

  clearFilter(columnKey: string): void {
    this.filters[columnKey] = '';
    this.pageIndex = 0;
    this.filterChange.emit(this.filters);
    this.refresh();
  }

  getFilterOptions(definition: GomTableFilterDefinition<T>): GomSelectOption[] {
    let options: GomSelectOption[];
    if ((definition.optionSource ?? 'static') === 'static') {
      options = definition.options ?? [];
    } else {
      const values = new Map<string, string>();
      for (const row of this.rows) {
        const rawValue = definition.valueAccessor ? definition.valueAccessor(row) : row[definition.key];
        const value = this.stringifyCellValue(rawValue).trim();
        if (value && !values.has(value)) {
          values.set(value, value);
        }
      }
      options = [...values].map(([value, label]) => ({ value, label }));
    }

    if (definition.type === 'select' && !options.some((option) => option.value === '')) {
      return [{ label: `All ${definition.label}`, value: '' }, ...options];
    }
    return options;
  }

  getFilterOptionCount(definition: GomTableFilterDefinition<T>, value: string): number | undefined {
    return definition.options?.find((option) => option.value === value)?.count;
  }

  getFilterString(source: Record<string, GomTableFilterValue>, key: string): string {
    const value = source[key];
    return typeof value === 'string' ? value : '';
  }

  getFilterArray(source: Record<string, GomTableFilterValue>, key: string): string[] {
    const value = source[key];
    return Array.isArray(value) ? value : [];
  }

  getFilterRange(source: Record<string, GomTableFilterValue>, key: string): { from: string; to: string } {
    const value = source[key];
    return value && !Array.isArray(value) && typeof value === 'object'
      ? value
      : { from: '', to: '' };
  }

  setDraftFilterValue(key: string, value: GomTableFilterValue): void {
    this.draftAdvancedFilters = { ...this.draftAdvancedFilters, [key]: value };
  }

  isDraftOptionSelected(key: string, value: string): boolean {
    const selected = this.draftAdvancedFilters[key];
    return Array.isArray(selected) ? selected.includes(value) : selected === value;
  }

  toggleDraftFilterOption(filter: GomTableFilterDefinition<T>, value: string): void {
    if (filter.mobileControl === 'checkboxes' || filter.type === 'multi-select') {
      const selected = this.getFilterArray(this.draftAdvancedFilters, filter.key);
      this.setDraftFilterValue(
        filter.key,
        selected.includes(value) ? selected.filter((item) => item !== value) : [...selected, value]
      );
      return;
    }
    this.setDraftFilterValue(filter.key, value);
  }

  setDraftDateRangeValue(key: string, boundary: 'from' | 'to', value: string): void {
    const current = this.getFilterRange(this.draftAdvancedFilters, key);
    this.setDraftFilterValue(key, { ...current, [boundary]: value });
  }

  setQuickFilterValue(key: string, value: GomTableFilterValue): void {
    this.advancedFilters = { ...this.advancedFilters, [key]: value };
    this.draftAdvancedFilters = this.cloneFilterValues(this.advancedFilters);
    this.pageIndex = 0;
    this.refresh();
  }

  changePageSize(nextPageSize: number): void {
    this.pageSize = Number(nextPageSize);
    this.pageIndex = 0;
    this.emitPageChange();
    this.refresh();
  }

  onPageSizeSelectChange(value: string): void {
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) {
      return;
    }

    this.changePageSize(parsed);
  }

  previousPage(): void {
    if (!this.canGoPrevious) {
      return;
    }
    this.pageIndex -= 1;
    this.emitPageChange();
    this.refresh();
  }

  goToPage(pageNumber: number): void {
    const nextPageIndex = Math.min(Math.max(Math.trunc(pageNumber) - 1, 0), this.totalPages - 1);
    if (nextPageIndex === this.pageIndex) {
      return;
    }
    this.pageIndex = nextPageIndex;
    this.emitPageChange();
    this.refresh();
  }

  nextPage(): void {
    if (!this.canGoNext) {
      return;
    }
    this.pageIndex += 1;
    this.emitPageChange();
    this.refresh();
  }

  requestLoadMore(): void {
    if (!this.canGoNext || this.loading) {
      return;
    }
    if (this.dataMode === 'client') {
      this.nextPage();
      return;
    }
    if (this.mobileLoadMoreStrategy === 'page-query') {
      this.pageIndex += 1;
      this.emitPageChange();
      this.queryChange.emit(this.buildQuery());
      return;
    }
    this.loadMore.emit({ pageIndex: this.pageIndex + 1, pageSize: this.pageSize });
  }

  getSortDirection(columnKey: string): GomSortDirection {
    return this.sortState.key === columnKey ? this.sortState.direction : '';
  }

  getHeaderAlign(column: GomTableColumn<T>): GomTableAlign {
    return column.headerAlign ?? 'left';
  }

  getCellAlign(column: GomTableColumn<T>): GomTableAlign {
    return column.cellAlign ?? 'left';
  }

  getTextMode(column: GomTableColumn<T>): GomTableTextMode {
    return column.textMode ?? 'truncate';
  }

  getCellValue(row: T, column: GomTableColumn<T>): string {
    const rawValue = row[column.key];
    if (column.format) {
      return column.format(rawValue, row);
    }
    return this.stringifyCellValue(rawValue);
  }

  getCellTitle(row: T, column: GomTableColumn<T>): string {
    const rawValue = row[column.key];
    if (column.tooltip) {
      return column.tooltip(rawValue, row);
    }
    return this.getCellValue(row, column);
  }

  getCellClass(row: T, column: GomTableColumn<T>): string {
    const rawValue = row[column.key];
    if (column.cellClass) {
      return column.cellClass(rawValue, row);
    }
    return '';
  }

  getEditableConfig(column: GomTableColumn<T>): GomTableEditableConfig<T> | null {
    if (!column.editable) {
      return null;
    }
    return column.editable === true ? {} : column.editable;
  }

  isCellEditDisabled(row: T, column: GomTableColumn<T>): boolean {
    return this.getEditableConfig(column)?.disabled?.(row) ?? false;
  }

  isCellEditing(row: T, column: GomTableColumn<T>): boolean {
    const config = this.getEditableConfig(column);
    return !!config && (config.mode === 'always' || this.getCellEditState(row, column) !== null);
  }

  getCellEditType(column: GomTableColumn<T>): 'text' | 'number' {
    return this.getEditableConfig(column)?.type ?? 'text';
  }

  getCellEditInputType(column: GomTableColumn<T>): 'text' {
    // Native number inputs sanitize intermediate decimal drafts such as `151.`
    // to an empty value. Keep the draft textual and validate/convert on commit.
    return 'text';
  }

  getCellEditInputMode(column: GomTableColumn<T>): 'text' | 'decimal' {
    return this.getCellEditType(column) === 'number' ? 'decimal' : 'text';
  }

  getCellDraft(row: T, column: GomTableColumn<T>): string {
    return this.getCellEditState(row, column)?.draft ?? this.stringifyCellValue(row[column.key]);
  }

  getCellEditError(row: T, column: GomTableColumn<T>): string {
    return this.getCellEditState(row, column)?.error ?? '';
  }

  startCellEdit(event: Event, row: T, column: GomTableColumn<T>): void {
    event.stopPropagation();
    if (!this.getEditableConfig(column) || this.isCellEditDisabled(row, column)) {
      return;
    }

    this.ensureCellEditState(row, column);
    this.changeDetector.markForCheck();
    const cell = (event.currentTarget as HTMLElement | null)?.closest('td');
    globalThis.setTimeout(() => {
      const input = cell?.querySelector<HTMLInputElement>('.gom-table-cell-editor input');
      input?.focus();
      input?.select();
    });
  }

  onCellEditTriggerKeydown(event: KeyboardEvent, row: T, column: GomTableColumn<T>): void {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      this.startCellEdit(event, row, column);
    }
  }

  setCellDraft(row: T, column: GomTableColumn<T>, value: string): void {
    const state = this.ensureCellEditState(row, column);
    state.draft = value;
    state.error = '';
  }

  onCellEditorKeydown(event: KeyboardEvent, row: T, column: GomTableColumn<T>): void {
    event.stopPropagation();
    if (event.altKey && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
      event.preventDefault();
      this.commitAndMoveCellEdit(row, column, event.key === 'ArrowDown' ? 1 : -1);
      return;
    }

    if (event.key === 'Enter') {
      event.preventDefault();
      this.commitCellEdit(row, column);
    } else if (event.key === 'Escape') {
      event.preventDefault();
      this.cancelCellEdit(row, column);
    }
  }

  commitCellEdit(row: T, column: GomTableColumn<T>): void {
    const state = this.getCellEditState(row, column);
    if (!state || this.isCellEditDisabled(row, column)) {
      return;
    }

    const result = this.validateCellDraft(column, state.draft);
    if (result.error) {
      state.error = result.error;
      this.changeDetector.markForCheck();
      return;
    }

    this.deleteCellEditState(row, column);
    if (!Object.is(state.previousValue, result.value)) {
      this.cellEdit.emit({
        row,
        columnKey: column.key,
        previousValue: state.previousValue,
        value: result.value,
      });
    }
    this.changeDetector.markForCheck();
  }

  cancelCellEdit(row: T, column: GomTableColumn<T>): void {
    this.deleteCellEditState(row, column);
    this.changeDetector.markForCheck();
  }

  private commitAndMoveCellEdit(row: T, column: GomTableColumn<T>, direction: -1 | 1): void {
    const currentIndex = this.displayedRows.indexOf(row);
    if (currentIndex < 0) {
      return;
    }

    let targetIndex = currentIndex + direction;
    while (
      targetIndex >= 0
      && targetIndex < this.displayedRows.length
      && this.isCellEditDisabled(this.displayedRows[targetIndex], column)
    ) {
      targetIndex += direction;
    }

    const targetRow = this.displayedRows[targetIndex];
    if (!targetRow) {
      return;
    }

    this.pendingCellNavigation = {
      rowKey: this.getRowKey(targetRow, targetIndex),
      columnKey: column.key,
    };
    this.commitCellEdit(row, column);
    this.schedulePendingCellNavigation();
  }

  private schedulePendingCellNavigation(): void {
    if (this.pendingCellNavigationTimer) {
      clearTimeout(this.pendingCellNavigationTimer);
    }

    this.pendingCellNavigationTimer = globalThis.setTimeout(() => {
      this.pendingCellNavigationTimer = null;
      const pending = this.pendingCellNavigation;
      if (!pending) {
        return;
      }

      const column = this.visibleColumns.find((candidate) => candidate.key === pending.columnKey);
      const rowIndex = this.displayedRows.findIndex(
        (candidate, index) => this.getRowKey(candidate, index) === pending.rowKey
      );
      const row = this.displayedRows[rowIndex];
      if (!column || !row || this.isCellEditDisabled(row, column)) {
        this.pendingCellNavigation = null;
        return;
      }

      this.ensureCellEditState(row, column);
      this.changeDetector.markForCheck();
      this.focusCellEditor(rowIndex, column);
    });
  }

  private focusCellEditor(rowIndex: number, column: GomTableColumn<T>): void {
    const columnIndex = this.visibleColumns.findIndex((candidate) => candidate.key === column.key);
    if (columnIndex < 0) {
      return;
    }

    globalThis.setTimeout(() => {
      const hostElement = this.host.nativeElement as HTMLElement;
      const tableRows = hostElement.querySelectorAll('tbody > tr') as NodeListOf<HTMLTableRowElement>;
      const tableRow = tableRows.item(rowIndex);
      const selectionOffset = this.enableRowSelection ? 1 : 0;
      const tableCell = tableRow?.cells.item(columnIndex + selectionOffset);
      const input = tableCell?.querySelector('.gom-table-cell-editor input') as HTMLInputElement | null;
      if (input) {
        input.focus();
        input.select();
        this.pendingCellNavigation = null;
      } else if (this.pendingCellNavigation) {
        this.schedulePendingCellNavigation();
      }
    });
  }

  getChipTone(row: T, column: GomTableColumn<T>): GomChipTone {
    const rawValue = row[column.key];
    if (!column.chipTone) {
      return 'neutral';
    }
    if (typeof column.chipTone === 'function') {
      return column.chipTone(rawValue, row);
    }
    return column.chipTone;
  }

  getCellActionKey(row: T, column: GomTableColumn<T>): string | null {
    if (!column.clickActionKey) {
      return null;
    }
    if (typeof column.clickActionKey === 'function') {
      return column.clickActionKey(row);
    }
    return column.clickActionKey;
  }

  getCellActionIcon(row: T, column: GomTableColumn<T>): string | null {
    if (!column.clickActionIcon) {
      return null;
    }
    if (typeof column.clickActionIcon === 'function') {
      return column.clickActionIcon(row) || null;
    }
    return column.clickActionIcon;
  }

  onCellActionClick(event: Event, actionKey: string, row: T): void {
    event.stopPropagation();
    this.triggerRowAction(actionKey, row);
  }

  onCellActionKeydown(event: KeyboardEvent, actionKey: string, row: T): void {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      this.onCellActionClick(event, actionKey, row);
    }
  }

  private getCellEditState(row: T, column: GomTableColumn<T>): { previousValue: unknown; draft: string; error: string } | null {
    return this.cellEditStates.get(row)?.get(column.key) ?? null;
  }

  private ensureCellEditState(row: T, column: GomTableColumn<T>): { previousValue: unknown; draft: string; error: string } {
    let rowStates = this.cellEditStates.get(row);
    if (!rowStates) {
      rowStates = new Map();
      this.cellEditStates.set(row, rowStates);
    }

    let state = rowStates.get(column.key);
    if (!state) {
      const previousValue = row[column.key];
      state = { previousValue, draft: this.stringifyCellValue(previousValue), error: '' };
      rowStates.set(column.key, state);
    }
    return state;
  }

  private deleteCellEditState(row: T, column: GomTableColumn<T>): void {
    const rowStates = this.cellEditStates.get(row);
    rowStates?.delete(column.key);
    if (rowStates?.size === 0) {
      this.cellEditStates.delete(row);
    }
  }

  private validateCellDraft(
    column: GomTableColumn<T>,
    draft: string
  ): { value: string | number; error: string } {
    const config = this.getEditableConfig(column);
    if (config?.type !== 'number') {
      return { value: draft, error: '' };
    }

    if (draft.trim() === '') {
      return { value: draft, error: `${column.header} is required.` };
    }

    const value = this.parseNumericDraft(draft);
    if (value === null) {
      return { value: draft, error: `Enter a valid ${column.header.toLowerCase()}.` };
    }
    if (config.min !== undefined && value < config.min) {
      return { value, error: `${column.header} must be at least ${config.min}.` };
    }
    if (config.max !== undefined && value > config.max) {
      return { value, error: `${column.header} must be at most ${config.max}.` };
    }
    if (config.step !== undefined && config.step > 0) {
      const stepBase = config.min ?? 0;
      const steps = (value - stepBase) / config.step;
      if (Math.abs(steps - Math.round(steps)) > 1e-9) {
        return { value, error: `${column.header} must use increments of ${config.step}.` };
      }
    }
    return { value, error: '' };
  }

  private parseNumericDraft(draft: string): number | null {
    const trimmed = draft.trim();
    if (!trimmed) {
      return null;
    }

    const normalized = trimmed.includes('.') && trimmed.includes(',')
      ? trimmed.replaceAll(',', '')
      : trimmed.replace(',', '.');
    const value = Number(normalized);

    return Number.isFinite(value) ? value : null;
  }

  hasActionButtons(column: GomTableColumn<T>): boolean {
    return !!column.actionButtons?.length;
  }

  getActionButtons(column: GomTableColumn<T>): GomTableActionButton<T>[] {
    return column.actionButtons ?? [];
  }

  hasOverflowMenu(column: GomTableColumn<T>): boolean {
    const config = column.actionOverflowMenu;
    if (!config?.actionKeys?.length || !column.actionButtons?.length) {
      return false;
    }

    const configuredKeys = new Set(config.actionKeys);
    return column.actionButtons.some((action) => configuredKeys.has(action.actionKey));
  }

  getInlineActionButtons(column: GomTableColumn<T>): GomTableActionButton<T>[] {
    const actions = column.actionButtons ?? [];
    const overflowKeys = new Set(column.actionOverflowMenu?.actionKeys ?? []);
    if (!overflowKeys.size) {
      return actions;
    }

    return actions.filter((action) => !overflowKeys.has(action.actionKey));
  }

  getOverflowActionButtons(column: GomTableColumn<T>): GomTableActionButton<T>[] {
    const actions = column.actionButtons ?? [];
    const overflowKeys = new Set(column.actionOverflowMenu?.actionKeys ?? []);
    if (!overflowKeys.size) {
      return [];
    }

    return actions.filter((action) => overflowKeys.has(action.actionKey));
  }

  getOverflowMenuConfig(column: GomTableColumn<T>): GomTableActionOverflowMenu<T> | null {
    return column.actionOverflowMenu ?? null;
  }

  getOverflowMenuTriggerIcon(column: GomTableColumn<T>): string {
    return column.actionOverflowMenu?.triggerIcon || 'ri-more-2-fill';
  }

  getOverflowMenuTriggerAriaLabel(column: GomTableColumn<T>): string {
    return column.actionOverflowMenu?.triggerAriaLabel || 'More actions';
  }

  getOverflowMenuTriggerTitle(column: GomTableColumn<T>): string {
    return column.actionOverflowMenu?.triggerButtonTitle || 'More actions';
  }

  getOverflowMenuBackButtonText(column: GomTableColumn<T>): string {
    return column.actionOverflowMenu?.backButtonText || column.header || 'Actions';
  }

  getOverflowMenuList(column: GomTableColumn<T>, row: T): MenuList {
    const mainMenu: MainMenuList[] = this.getOverflowActionButtons(column).map((action) => {
      const subActions = this.getSubActions(action);
      if (subActions.length > 0) {
        return {
          title: this.getActionLabel(action, row),
          icon: this.getActionIcon(action, row) || 'ri-more-line',
          submenu: subActions.map((subAction) => ({
            title: this.getActionLabel(subAction, row),
            icon: this.getActionIcon(subAction, row) || 'ri-arrow-right-line',
            clickEvent: (event: Event) => {
              event.stopPropagation();
              this.triggerRowAction(subAction.actionKey, row);
            },
          })),
        };
      }

      return {
        title: this.getActionLabel(action, row),
        icon: this.getActionIcon(action, row) || 'ri-arrow-right-line',
        clickEvent: (event: Event) => {
          event.stopPropagation();
          this.triggerRowAction(action.actionKey, row);
        },
      };
    });

    return {
      mainMenu,
      portalMenu: [],
    };
  }

  triggerRowAction(actionKey: string, row: T): void {
    this.submenuOpenKey = null;
    this.submenuPosition = null;
    this.rowAction.emit({ actionKey, row });
  }

  toggleSubmenu(event: Event, action: GomTableActionButton<T>, row: T, rowIndex: number): void {
    event.stopPropagation();
    const key = this.getSubmenuKey(action, row, rowIndex);
    if (this.submenuOpenKey === key) {
      this.submenuOpenKey = null;
      this.submenuPosition = null;
      return;
    }
    const trigger = (event.target as HTMLElement).closest('button') ?? (event.target as HTMLElement);
    const rect = trigger.getBoundingClientRect();
    const estimatedMenuHeight = 180;
    const spaceBelow = window.innerHeight - rect.bottom;
    if (spaceBelow < estimatedMenuHeight) {
      this.submenuPosition = {
        bottom: `${window.innerHeight - rect.top + 4}px`,
        right: `${window.innerWidth - rect.right}px`,
        top: 'auto',
      };
    } else {
      this.submenuPosition = {
        top: `${rect.bottom + 4}px`,
        right: `${window.innerWidth - rect.right}px`,
        bottom: 'auto',
      };
    }
    this.submenuOpenKey = key;
  }

  isSubmenuOpen(action: GomTableActionButton<T>, row: T, rowIndex: number): boolean {
    return this.submenuOpenKey === this.getSubmenuKey(action, row, rowIndex);
  }

  getSubActions(action: GomTableActionButton<T>): GomTableActionButton<T>[] {
    return action.subActions ?? [];
  }

  onSubmenuActionClick(event: Event, actionKey: string, row: T): void {
    event.stopPropagation();
    this.triggerRowAction(actionKey, row);
  }

  onMobileCardClick(row: T): void {
    if (!this.mobileCardClickable) {
      return;
    }

    this.rowClick.emit(row);
  }

  getMobileCardActions(row: T): GomTableActionButton<T>[] {
    const actionColumn = this.mobileCardActionColumn;
    if (!actionColumn?.actionButtons?.length) {
      return [];
    }

    return actionColumn.actionButtons;
  }

  openMobileTableOptions(): void {
    this.mobileTableOptionsOpen = true;
    this.toolbarOptionsOpen = false;
  }

  closeMobileTableOptions(): void {
    this.mobileTableOptionsOpen = false;
  }

  toggleMobileColumnSearch(): void {
    this.toggleFilters();
    this.closeMobileTableOptions();
    if (this.filtersVisible) {
      requestAnimationFrame(() => {
        const tableWrap = this.host.nativeElement.querySelector('.gom-table-wrap') as HTMLElement | null;
        tableWrap?.scrollTo({ left: 0, behavior: 'smooth' });
      });
    }
  }

  openMobileColumnPanel(): void {
    this.columnPanelOpen = true;
    this.closeMobileTableOptions();
  }

  openMobileRowActions(row: T): void {
    this.mobileRowActionTarget = row;
    this.mobileRowActionsOpen = true;
  }

  closeMobileRowActions(): void {
    this.mobileRowActionsOpen = false;
    this.mobileRowActionTarget = null;
  }

  getMobileRowSheetActions(row: T): GomTableActionButton<T>[] {
    return this.getMobileCardActions(row).flatMap((action) =>
      action.subActions?.length ? action.subActions : [action]
    );
  }

  getMobileCardTitle(row: T, rowIndex: number): string {
    const titleKey = this.resolveMobileCardHeaderTitleKey(row);
    if (titleKey) {
      const value = this.getMobileCardValue(row, titleKey);
      if (value) {
        return value;
      }
    }

    return this.getMobileCardFallbackTitle(row, rowIndex);
  }

  getMobileCardSubtitleParts(row: T): string[] {
    return this.resolveMobileCardHeaderSubtitleKeys(row)
      .map((key) => this.getMobileCardValue(row, key))
      .filter((value) => value.length > 0)
      .slice(0, 2);
  }

  getMobileCardStatusLabel(row: T): string {
    const statusKey = this.resolveMobileCardHeaderStatusKey(row);
    if (!statusKey) {
      return '';
    }

    const value = this.getMobileCardValue(row, statusKey);
    if (!value) {
      return '';
    }

    if (String(statusKey).toLowerCase().includes('stock')) {
      return `${value} STOCK`;
    }

    return value;
  }

  getMobileCardStatusTone(row: T): GomChipTone {
    const statusKey = this.resolveMobileCardHeaderStatusKey(row);
    if (!statusKey) {
      return 'neutral';
    }

    if (String(statusKey).toLowerCase().includes('stock') && 'stockSeverity' in row) {
      const severityValue = (row as Record<string, unknown>)['stockSeverity'];
      const severity = typeof severityValue === 'string' ? severityValue.toLowerCase() : '';
      if (severity === 'critical') {
        return 'danger';
      }
      if (severity === 'low') {
        return 'warning';
      }
      return 'success';
    }

    return this.getMobileCardTone(row, statusKey);
  }

  hasMobileCardStatus(row: T): boolean {
    return this.getMobileCardStatusLabel(row).trim().length > 0;
  }

  getMobileCardVisibleFields(row: T): GomTableMobileCardField<T>[] {
    const configuredFields = this.mobileCardConfig?.body?.visibleFields;
    if (configuredFields !== undefined) {
      return configuredFields;
    }

    return this.getFallbackMobileCardFields(row).slice(0, 4).map((column) => ({
      key: column.key,
      label: column.header,
      width: 'half' as const,
    }));
  }

  getMobileCardExpandableFields(row: T): GomTableMobileCardField<T>[] {
    const configuredFields = this.mobileCardConfig?.body?.expandableFields;
    if (configuredFields !== undefined) {
      return configuredFields;
    }

    const visibleKeys = new Set([
      ...this.getMobileCardVisibleFields(row).map((field) => field.key),
      ...this.resolveMobileCardHeaderSubtitleKeys(row),
      ...(this.resolveMobileCardHeaderTitleKey(row) ? [this.resolveMobileCardHeaderTitleKey(row)!] : []),
      ...(this.resolveMobileCardHeaderStatusKey(row) ? [this.resolveMobileCardHeaderStatusKey(row)!] : []),
    ]);

    return this.getFallbackMobileCardFields(row)
      .filter((column) => !visibleKeys.has(column.key))
      .map((column) => ({
        key: column.key,
        label: column.header,
        width: 'half' as const,
      }));
  }

  hasMobileCardExpandableFields(row: T): boolean {
    return this.getMobileCardExpandableFields(row).length > 0;
  }

  isMobileCardExpanded(row: T, rowIndex: number): boolean {
    const rowKey = this.getRowKey(row, rowIndex);
    if (this.mobileCardConfig?.body?.defaultExpanded) {
      return true;
    }

    return this.mobileCardExpandedRowKeys.has(rowKey);
  }

  toggleMobileCardDetails(event: Event, row: T, rowIndex: number): void {
    event.stopPropagation();
    const rowKey = this.getRowKey(row, rowIndex);
    if (this.mobileCardExpandedRowKeys.has(rowKey)) {
      this.mobileCardExpandedRowKeys.delete(rowKey);
      return;
    }

    this.mobileCardExpandedRowKeys.add(rowKey);
  }

  getMobileCardDetailsToggleLabel(row: T, rowIndex: number): string {
    const expanded = this.isMobileCardExpanded(row, rowIndex);
    const footer = this.mobileCardConfig?.footer;
    return expanded
      ? (footer?.collapseLabel || 'View Less Details ↑')
      : (footer?.expandLabel || 'View More Details ↓');
  }

  shouldShowMobileCardDetailsToggle(row: T): boolean {
    const footer = this.mobileCardConfig?.footer;
    if (footer?.showDetailsToggle === false) {
      return false;
    }

    return this.hasMobileCardExpandableFields(row);
  }

  hasMobileCardBody(row: T, rowIndex: number): boolean {
    return (
      this.getMobileCardVisibleFields(row).length > 0
      || this.shouldShowMobileCardDetailsToggle(row)
      || (this.isMobileCardExpanded(row, rowIndex) && this.getMobileCardExpandableFields(row).length > 0)
    );
  }

  getMobileCardPrimaryActions(row: T): GomTableActionButton<T>[] {
    const actionKeys = this.mobileCardConfig?.footer?.primaryActionKeys ?? [];
    if (!actionKeys.length) {
      return [];
    }

    return actionKeys
      .map((actionKey) => this.getMobileCardActionByKey(actionKey))
      .filter((action): action is GomTableActionButton<T> => !!action && !action.subActions?.length);
  }

  getMobileCardOverflowActions(row: T): GomTableActionButton<T>[] {
    const overflowActionKeys = this.mobileCardConfig?.header?.overflowActionKeys ?? [];
    if (!overflowActionKeys.length) {
      return [];
    }

    return overflowActionKeys
      .map((actionKey) => this.getMobileCardActionByKey(actionKey))
      .filter((action): action is GomTableActionButton<T> => !!action && !action.subActions?.length);
  }

  getMobileCardOverflowMenuList(row: T): MenuList {
    return {
      mainMenu: this.getMobileCardOverflowActions(row).map((action) => ({
        title: this.getActionLabel(action, row),
        icon: this.getMobileCardActionIcon(action, row) || 'ri-more-line',
        clickEvent: (event) => this.onMobileCardOverflowActionClick(event, action.actionKey, row),
      })),
      portalMenu: [],
    };
  }

  getMobileCardActionLabel(action: GomTableActionButton<T>, row: T): string {
    return this.getActionLabel(action, row);
  }

  getMobileCardActionIcon(action: GomTableActionButton<T>, row: T): string | null {
    return this.getActionIcon(action, row);
  }

  showMobileCardPrimaryActionLabels(): boolean {
    return this.mobileCardConfig?.footer?.showPrimaryActionLabels !== false;
  }

  onMobileCardOverflowActionClick(event: Event, actionKey: string, row: T): void {
    event.stopPropagation();
    this.triggerRowAction(actionKey, row);
  }

  getMobileCardFieldLabel(row: T, field: GomTableMobileCardField<T>): string {
    return field.label || this.getMobileCardValueLabel(row, field.key);
  }

  getMobileCardFieldValue(row: T, field: GomTableMobileCardField<T>): string {
    const rawValue = this.getMobileCardValue(row, field.key);
    if (field.format) {
      return field.format(rawValue, row);
    }

    return rawValue;
  }

  isMobileCardFieldHidden(row: T, field: GomTableMobileCardField<T>): boolean {
    return field.hideWhenEmpty !== false && this.getMobileCardFieldValue(row, field).trim().length === 0;
  }

  getMobileCardFieldWidth(field: GomTableMobileCardField<T>): string {
    return field.width === 'full' ? 'full' : 'half';
  }

  triggerMobileRowAction(actionKey: string): void {
    if (this.mobileRowActionTarget) {
      this.triggerRowAction(actionKey, this.mobileRowActionTarget);
    }
    this.closeMobileRowActions();
  }

  private getMobileCardValueLabel(row: T, key: keyof T & string | undefined): string {
    if (!key) {
      return '';
    }

    const column = this.columns.find((item) => item.key === key);
    return column?.header || key;
  }

  private getFallbackMobileCardFields(row: T): GomTableColumn<T>[] {
    const configuredKeys = new Set([
      ...(this.mobileCardConfig?.header?.subtitleKeys ?? []),
      ...(this.mobileCardConfig?.body?.visibleFields ?? []).map((field) => field.key),
      ...(this.mobileCardConfig?.body?.expandableFields ?? []).map((field) => field.key),
      ...(this.mobileCardConfig?.footer?.primaryActionKeys ?? []),
      ...(this.mobileCardConfig?.footer?.secondaryActionKeys ?? []),
    ]);

    const columns = this.visibleColumns.filter((column) => !this.hasActionButtons(column));
    return columns.filter((column) => !configuredKeys.has(column.key));
  }

  private resolveMobileCardHeaderTitleKey(row: T): keyof T & string | undefined {
    return this.mobileCardConfig?.header?.titleKey ?? this.getFallbackMobileCardFields(row)[0]?.key;
  }

  private resolveMobileCardHeaderSubtitleKeys(row: T): Array<keyof T & string> {
    if (this.mobileCardConfig?.header?.subtitleKeys?.length) {
      return this.mobileCardConfig.header.subtitleKeys;
    }

    return this.getFallbackMobileCardFields(row)
      .slice(1, 3)
      .map((column) => column.key);
  }

  private resolveMobileCardHeaderStatusKey(row: T): keyof T & string | undefined {
    if (this.mobileCardConfig?.header?.statusKey) {
      return this.mobileCardConfig.header.statusKey;
    }

    return this.getFallbackMobileCardFields(row).find((column) =>
      Boolean(column.chipTone) || /status|state|payment/i.test(column.header)
    )?.key;
  }

  private getMobileCardFallbackTitle(row: T, rowIndex: number): string {
    const columns = this.getFallbackMobileCardFields(row);
    const primaryColumn = columns[0];
    if (!primaryColumn) {
      return `Row ${rowIndex + 1}`;
    }

    return this.getMobileCardValue(row, primaryColumn.key) || `Row ${rowIndex + 1}`;
  }

  private getMobileCardActionByKey(actionKey: string): GomTableActionButton<T> | null {
    for (const column of this.columns) {
      if (!column.actionButtons?.length) {
        continue;
      }

      const action = this.findActionButtonByKey(column.actionButtons, actionKey);
      if (action) {
        return action;
      }
    }

    return null;
  }

  private findActionButtonByKey(actions: GomTableActionButton<T>[], actionKey: string): GomTableActionButton<T> | null {
    for (const action of actions) {
      if (action.actionKey === actionKey) {
        return action;
      }

      if (action.subActions?.length) {
        const nestedAction = this.findActionButtonByKey(action.subActions, actionKey);
        if (nestedAction) {
          return nestedAction;
        }
      }
    }

    return null;
  }

  getMobileCardValue(row: T, key: keyof T & string | undefined): string {
    if (!key) {
      return '';
    }
    const column = this.columns.find((item) => item.key === key);
    return column ? this.getCellValue(row, column) : this.stringifyCellValue(row[key]);
  }

  getMobileCardTone(row: T, key: keyof T & string | undefined): GomChipTone {
    const column = key ? this.columns.find((item) => item.key === key) : undefined;
    if (column) {
      return this.getChipTone(row, column);
    }
    const value = this.getMobileCardValue(row, key).toLowerCase();
    if (value === 'paid' || value.includes('delivered')) {
      return 'success';
    }
    if (value.includes('refund') || value.includes('cancel') || value.includes('failed')) {
      return 'danger';
    }
    if (value.includes('return')) {
      return 'warning';
    }
    if (value.includes('ship') || value.includes('confirm')) {
      return 'info';
    }
    return 'neutral';
  }

  getMobileCardInitials(row: T): string {
    const value = this.getMobileCardValue(row, this.resolveMobileCardHeaderTitleKey(row));
    const words = value.trim().split(/\s+/).filter(Boolean);
    return words.slice(0, 2).map((word) => word.charAt(0).toUpperCase()).join('') || '—';
  }

  setMobileSort(column: GomTableColumn<T>): void {
    this.setSort(column);
    this.mobileTableOptionsOpen = false;
  }

  onMobileCardActionClick(event: Event, actionKey: string, row: T): void {
    event.stopPropagation();
    this.triggerRowAction(actionKey, row);
  }

  handleHeaderKeydown(event: KeyboardEvent, column: GomTableColumn<T>): void {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      this.setSort(column);
    }
  }

  closeColumnPanel(): void {
    this.columnPanelOpen = false;
  }

  isRowSelected(row: T, rowIndex: number): boolean {
    return this.selectedRowKeys.has(this.getRowKey(row, rowIndex));
  }

  areAllDisplayedRowsSelected(): boolean {
    if (!this.displayedRows.length) {
      return false;
    }

    return this.displayedRows.every((row, rowIndex) => this.selectedRowKeys.has(this.getRowKey(row, rowIndex)));
  }

  toggleRowSelection(row: T, rowIndex: number, selected: boolean): void {
    if (!this.enableRowSelection) {
      return;
    }

    const key = this.getRowKey(row, rowIndex);
    if (selected) {
      this.selectedRowKeys.add(key);
    } else {
      this.selectedRowKeys.delete(key);
    }
    this.emitSelectedRows();
  }

  toggleSelectAllDisplayedRows(selected: boolean): void {
    if (!this.enableRowSelection) {
      return;
    }

    this.displayedRows.forEach((row, rowIndex) => {
      const key = this.getRowKey(row, rowIndex);
      if (selected) {
        this.selectedRowKeys.add(key);
      } else {
        this.selectedRowKeys.delete(key);
      }
    });

    this.emitSelectedRows();
  }

  setMobileViewMode(mode: 'cards' | 'table'): void {
    this.mobileViewMode = mode;
    this.syncMobileLoadMoreObserver();
  }

  @HostListener('window:resize')
  onResize(): void {
    this.updateViewportMode();
    this.scheduleFilterNavigationLayout();
    this.syncMobileLoadMoreObserver();
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event): void {
    const target = event.target as Node | null;
    if (this.toolbarOptionsOpen && target && !this.host.nativeElement.querySelector('.gom-table-options')?.contains(target)) {
      this.toolbarOptionsOpen = false;
    }
    if (this.navigationOverflowOpenKey && target) {
      const overflowMenus = this.host.nativeElement.querySelectorAll('.gom-table-filter-navigation__more');
      if (![...overflowMenus].some((menu) => menu.contains(target))) {
        this.navigationOverflowOpenKey = null;
      }
    }
    if (!this.submenuOpenKey) {
      return;
    }

    if (!this.host.nativeElement.contains(event.target as Node)) {
      this.submenuOpenKey = null;
      this.submenuPosition = null;
    }
  }

  @HostListener('document:keydown', ['$event'])
  onDocumentKeydown(event: KeyboardEvent): void {
    if (event.key === 'Escape' && (this.submenuOpenKey || this.toolbarOptionsOpen || this.navigationOverflowOpenKey)) {
      event.preventDefault();
      this.submenuOpenKey = null;
      this.submenuPosition = null;
      this.toolbarOptionsOpen = false;
      this.navigationOverflowOpenKey = null;
    }
  }

  readonly trackByColumn = (_: number, column: GomTableColumn<T>): string => column.key;
  readonly trackByRow = (index: number): number => index;

  private getNextSortDirection(columnKey: string): GomSortDirection {
    const current = this.getSortDirection(columnKey);
    if (current === '') {
      return 'asc';
    }
    if (current === 'asc') {
      return 'desc';
    }
    return '';
  }

  private initializeVisibleColumns(): void {
    if (!this.columns.length) {
      this.visibleColumnKeys.clear();
      return;
    }

    if (this.visibleColumnKeys.size === 0) {
      this.columns
        .filter((column) => !column.hiddenByDefault)
        .forEach((column) => this.visibleColumnKeys.add(column.key));
      return;
    }

    const available = new Set(this.columns.map((column) => column.key));
    for (const key of this.visibleColumnKeys) {
      if (!available.has(key)) {
        this.visibleColumnKeys.delete(key);
      }
    }

    if (this.visibleColumnKeys.size === 0) {
      this.columns.forEach((column) => this.visibleColumnKeys.add(column.key));
    }
  }

  private refresh(): void {
    if (this.dataMode === 'client') {
      this.runClientMode();
    } else {
      this.syncServerModeRows();
      this.queryChange.emit(this.buildQuery());
    }
  }

  private runClientMode(): void {
    const result = this.tableService.runClientPipeline(
      this.rows,
      this.columns,
      this.buildQuery(),
      this.advancedFilterDefinitions
    );
    this.displayedRows = result.rows;
    this.filteredTotal = result.filteredTotal;
  }

  private syncServerModeRows(): void {
    if (this.isMobileLoadMoreActive() && this.mobileLoadMoreStrategy === 'page-query') {
      const pageChangedWithoutFreshRows = this.pageIndex !== this.lastSyncedServerPageIndex
        && this.rows === this.lastSyncedServerRowsRef;

      if (pageChangedWithoutFreshRows) {
        this.displayedRows = this.accumulatedServerRows.length > 0 ? this.accumulatedServerRows : this.rows;
        this.filteredTotal = this.totalItems;
        return;
      }

      if (this.pageIndex === 0) {
        this.accumulatedServerRows = [...this.rows];
        this.lastAccumulatedPageIndex = 0;
      } else if (this.pageIndex === this.lastAccumulatedPageIndex + 1) {
        this.accumulatedServerRows = this.mergeServerRows(this.accumulatedServerRows, this.rows);
        this.lastAccumulatedPageIndex = this.pageIndex;
      } else {
        this.accumulatedServerRows = [...this.rows];
        this.lastAccumulatedPageIndex = this.pageIndex;
      }

      this.displayedRows = this.accumulatedServerRows;
      this.filteredTotal = this.totalItems;
      this.lastSyncedServerRowsRef = this.rows;
      this.lastSyncedServerPageIndex = this.pageIndex;
      return;
    }

    this.accumulatedServerRows = [];
    this.lastAccumulatedPageIndex = 0;
    this.lastSyncedServerRowsRef = null;
    this.lastSyncedServerPageIndex = -1;
    this.displayedRows = this.rows;
    this.filteredTotal = this.totalItems;
  }

  private isMobileLoadMoreActive(): boolean {
    return this.mobileCardView
      && this.mobilePaginationMode === 'load-more'
      && this.isMobileViewport
      && this.mobileViewMode === 'cards';
  }

  private mergeServerRows(existingRows: T[], nextRows: T[]): T[] {
    const merged = [...existingRows];
    const existingIds = new Set(
      existingRows
        .map((row) => row['_id'])
        .filter((value): value is string => typeof value === 'string' && value.length > 0)
    );

    nextRows.forEach((row) => {
      const rowId = row['_id'];
      if (typeof rowId === 'string' && rowId.length > 0) {
        if (!existingIds.has(rowId)) {
          merged.push(row);
          existingIds.add(rowId);
        }
        return;
      }
      merged.push(row);
    });

    return merged;
  }

  private shouldObserveMobileLoadMoreSentinel(): boolean {
    return this.mobileAutoLoadMore
      && this.mobilePaginationMode === 'load-more'
      && this.mobileCardView
      && this.showPagination
      && this.isMobileViewport
      && this.mobileViewMode === 'cards';
  }

  private syncMobileLoadMoreObserver(): void {
    this.mobileLoadMoreObserver?.disconnect();
    this.mobileLoadMoreObserver = null;
    this.mobileLoadMoreSentinelInView = false;

    if (typeof IntersectionObserver === 'undefined' || !this.shouldObserveMobileLoadMoreSentinel()) {
      return;
    }

    const sentinel = this.mobileLoadMoreSentinel?.nativeElement;
    if (!sentinel) {
      return;
    }

    this.mobileLoadMoreObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) {
            this.mobileLoadMoreSentinelInView = false;
            return;
          }

          if (this.mobileLoadMoreSentinelInView) {
            return;
          }

          this.mobileLoadMoreSentinelInView = true;
          this.maybeAutoLoadMore();
        });
      },
      {
        root: null,
        rootMargin: '160px 0px',
        threshold: 0.01,
      }
    );

    this.mobileLoadMoreObserver.observe(sentinel);
  }

  private maybeAutoLoadMore(): void {
    if (!this.shouldObserveMobileLoadMoreSentinel()) {
      return;
    }
    if (!this.canGoNext || this.loading) {
      return;
    }

    const now = Date.now();
    if (now < this.autoLoadMoreCooldownUntil) {
      return;
    }

    this.autoLoadMoreCooldownUntil = now + 500;
    this.requestLoadMore();
  }

  private emitPageChange(): void {
    this.pageChange.emit({ pageIndex: this.pageIndex, pageSize: this.pageSize });
  }

  private buildQuery(): GomTableQuery {
    return {
      searchTerm: this.searchTerm,
      sort: this.sortState,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      filters: this.filters,
      visibleColumnKeys: [...this.visibleColumnKeys],
      advancedFilters: this.cloneFilterValues(this.advancedFilters),
      globalSearchScope: this.globalSearchScope,
    };
  }

  private stringifyCellValue(value: unknown): string {
    if (value === null || value === undefined) {
      return '';
    }
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      return String(value);
    }
    if (value instanceof Date) {
      return value.toISOString();
    }
    return JSON.stringify(value);
  }

  private formatFilterValue(
    definition: GomTableFilterDefinition<T> | undefined,
    value: GomTableFilterValue
  ): string {
    if (Array.isArray(value)) {
      return value.map((item) => definition?.options?.find((option) => option.value === item)?.label ?? item).join(', ');
    }
    if (typeof value === 'object') {
      return [value.from, value.to].filter(Boolean).join(' – ');
    }
    return definition?.options?.find((option) => option.value === value)?.label ?? value;
  }

  private hasFilterValue(value: GomTableFilterValue | undefined): boolean {
    if (typeof value === 'string') {
      return value.trim().length > 0;
    }
    if (Array.isArray(value)) {
      return value.length > 0;
    }
    return !!value && (!!value.from || !!value.to);
  }

  private cloneFilterValues(values: Record<string, GomTableFilterValue>): Record<string, GomTableFilterValue> {
    return Object.fromEntries(Object.entries(values).map(([key, value]) => {
      if (Array.isArray(value)) {
        return [key, [...value]];
      }
      if (value && typeof value === 'object') {
        return [key, { ...value }];
      }
      return [key, value];
    }));
  }

  private updateViewportMode(): void {
    this.isMobileViewport = typeof window !== 'undefined' && window.matchMedia('(max-width: 48rem)').matches;
  }

  private observeFilterNavigationRows(): void {
    if (typeof ResizeObserver === 'undefined') {
      return;
    }
    this.navigationResizeObserver?.disconnect();
    this.navigationResizeObserver = new ResizeObserver(() => this.scheduleFilterNavigationLayout());
    this.navigationResizeObserver.observe(this.host.nativeElement);
  }

  private scheduleFilterNavigationLayout(): void {
    if (this.navigationLayoutTimer) {
      clearTimeout(this.navigationLayoutTimer);
    }
    this.navigationLayoutTimer = setTimeout(() => {
      this.navigationLayoutTimer = null;
      this.updateFilterNavigationLayout();
    });
  }

  private updateFilterNavigationLayout(): void {
    const nextCounts: Record<string, number> = {};
    for (const row of this.filterNavigationRows) {
      const container = this.findFilterNavigationElement('data-filter-navigation-options', row.key);
      const options = this.getFilterNavigationOptions(row);
      nextCounts[row.key] = container
        ? this.calculateVisibleNavigationOptionCount(container, row.key, options.length)
        : options.length;
    }
    this.navigationVisibleOptionCounts = nextCounts;
    this.changeDetector.markForCheck();
  }

  private calculateVisibleNavigationOptionCount(container: HTMLElement, rowKey: string, optionCount: number): number {
    const renderedOptions = Array.from(
      container.querySelectorAll('[data-filter-navigation-option]') as NodeListOf<HTMLElement>
    );
    if (renderedOptions.length === optionCount) {
      this.navigationOptionWidths.set(rowKey, renderedOptions.map((option) => option.getBoundingClientRect().width));
    }
    const widths = this.navigationOptionWidths.get(rowKey);
    if (widths?.length !== optionCount) {
      return optionCount;
    }

    const styles = getComputedStyle(container);
    const gap = Number.parseFloat(styles.columnGap || styles.gap || '0') || 0;
    const totalWidth = widths.reduce((total, width) => total + width, 0) + gap * Math.max(0, widths.length - 1);
    if (totalWidth <= container.clientWidth) {
      return optionCount;
    }

    const overflowButtonWidth = 44;
    let usedWidth = overflowButtonWidth + gap;
    let visibleCount = 0;
    for (const width of widths) {
      const nextWidth = width + (visibleCount > 0 ? gap : 0);
      if (usedWidth + nextWidth > container.clientWidth) {
        break;
      }
      usedWidth += nextWidth;
      visibleCount += 1;
    }
    return visibleCount;
  }

  private findFilterNavigationElement(attribute: string, key: string): HTMLElement | null {
    const elements = this.host.nativeElement.querySelectorAll(`[${attribute}]`) as NodeListOf<HTMLElement>;
    return Array.from(elements)
      .find((element) => element.getAttribute(attribute) === key) ?? null;
  }

  private clearSelection(): void {
    this.selectedRowKeys.clear();
    this.emitSelectedRows();
  }

  private emitSelectedRows(): void {
    const selectedRows = this.rows.filter((row, rowIndex) => this.selectedRowKeys.has(this.getRowKey(row, rowIndex)));
    this.selectedRowsChange.emit(selectedRows);
  }

  private getRowKey(row: T, rowIndex: number): string {
    const rowId = row['_id'];
    if (typeof rowId === 'string' || typeof rowId === 'number') {
      return String(rowId);
    }

    return `${this.pageIndex}:${rowIndex}`;
  }

  private getSubmenuKey(action: GomTableActionButton<T>, row: T, rowIndex: number): string {
    const rowId = typeof row['_id'] === 'string' || typeof row['_id'] === 'number'
      ? String(row['_id'])
      : String(rowIndex);
    return `${action.actionKey}::${rowId}`;
  }
}
