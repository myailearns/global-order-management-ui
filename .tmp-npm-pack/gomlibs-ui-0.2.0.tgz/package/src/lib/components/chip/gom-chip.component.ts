import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { GomChipTone } from '../table/gom-table.models';

@Component({
  selector: 'gom-lib-chip',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './gom-chip.component.html',
  styleUrl: './gom-chip.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GomChipComponent {
  @Input() tone: GomChipTone = 'neutral';
  @Input() size: 'default' | 'compact' | 'dense' = 'default';
  @Input() fullWidth = false;
  @Input() interactive = false;
  @Input() selected = false;
  @Input() disabled = false;
  @Input() ariaLabel = '';
  @Input() ariaRole = '';

  @Output() chipClick = new EventEmitter<MouseEvent>();

  handleClick(event: MouseEvent): void {
    if (this.disabled) {
      event.preventDefault();
      return;
    }
    this.chipClick.emit(event);
  }
}
